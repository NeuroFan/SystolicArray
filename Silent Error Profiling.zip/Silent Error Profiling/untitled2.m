count=0;
for i=1:100000
    a=randi([0,1],1,1);
    b= randi([0,1],1,1);
    sum = a || b;
    ea = (a && randi([0,1],1,1));
    eb = (b && randi([0,1],1,1));
    esum = ea  || eb;
    cond = (sum == esum);
    if ((sum == esum))
        if ((ea~=a)||(eb~=b))
            count = count + 1;
        end
    end
end
z=(100*count/100000)