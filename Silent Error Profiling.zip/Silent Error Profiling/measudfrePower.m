function [Power,PeakPower] = measurePower(allWaves, Voltage)
 Current  = allWaves(2).data;
 Current = resample(Current,allWaves(1).data,'linear');
 Power = mean(abs(Current)) * Voltage;
 PeakPower = max(abs(Current)) * Voltage;
 
 
 
end