echo "MATLAB and HSPICE required"
echo "Modify the following according to your system's settings"

# Setup HSPICE simulation tool before running MATLAB
source /usr/local/contrib/eda_tools_setup.bash 

matlab -r  " run GUI.m;"


