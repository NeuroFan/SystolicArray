clear
clc
N = 8; %matrix size N*N
factor = 1;
A = factor*randi([0 8],N,N);    
B = factor*randi([0 8],N,N);   

C = zeros(N+1,N+1);
transientData = zeros((N+1)^3,3); % p(i) = a(i)*b(i) + p(i-1); --> [a(i),b(i),p(i-1),p(i)]

[Ac,Ar,Af] = mat_ext(A);
[Bc,Br,Bf] = mat_ext(B);
ArScale=Ar;BcScale = Bc;
ArScale(end,:) = Ar(end,:);
BcScale(:,end) = Bc(:,end);

Mat_Mul = Ar * Bc;
Error_ABFT  = 1;
counter = 0;
error_Counter=0;
while((Error_ABFT==1))
            rndX = randi([1 N],1,1);
            rndY = randi([1 N],2,1);
            LSBs =  randi([-1 1],2,1); %only modify LSBs at this point
            for i = 1:1
                for j = 1: 2
                     Mat_Mul(rndX(i),rndY(j)) = Mat_Mul(rndX(i),rndY(j)) + LSBs(j);
                end
            end
            Error_ABFT = ABFTError(Mat_Mul);
            counter = counter + 1;
end
counter