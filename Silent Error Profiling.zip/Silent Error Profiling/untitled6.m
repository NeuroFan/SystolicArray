for i = 1:1000
    round (15 + 0.1 * (rand-0.5) * 15)
end