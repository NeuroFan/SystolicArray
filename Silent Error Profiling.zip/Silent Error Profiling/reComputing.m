Increase_in_freq = -5/100;
SET_UP_TIME_new = SET_UP_TIME_percent + Increase_in_freq;
[faultsList,allWaves,effective_clock_period] = check_data(SPICE_output_Data,SET_UP_TIME_new,Vdd);
effective_setup_time = effective_clock_period*SET_UP_TIME_percent;
%% Redo Computations but this time with faulty data
Mat_Mul = redo_matMul(faultsList,Mats);
%% Check for actual errors and ABFT detected errors
% hardware checks errors row by row only
errorThreshold = 0;
 MatDif = Mat_Mul-Mats.Original_Multipication;
 Error_Actual = (sum(abs(MatDif(:))>errorThreshold))>0 ;%1 means theres is an error; 0 means there is not
 Error_ABFT = ABFTError(Mat_Mul);
 

%% Show the results and Extract power consumption information for HSPICE 
%%Read power consumption results 
disp('----------------------');
disp(['Total number of error in all PEs of Systolic Array ' num2str(length(faultsList.MulIn1)-2)]);
disp(['Real Fault in Matrix result  ? ' num2str(Error_Actual)])
disp(['ABFT detected error in result? ' num2str(Error_ABFT)])
disp('-----------');
[Power,~] = measurePower(SPICE_output_Path, Vdd); 
ABFT_Overhead = 0; % for now, after simulations it will be inserted
disp(['@Vdd=' num2str(Vdd) ', @f_clk=' num2str((1/((1-Increase_in_freq)*CLOCK_PERIOD*TIME_STEP))/10^6) ' MHz' '->TotalPower=' num2str((1+Increase_in_freq)*MATRIX_SIZE^2*Power*10^6+ABFT_Overhead) 'uW' ', Power/PE=' num2str((1+Increase_in_freq)*Power*10^6) 'uW']);
disp('----------------------');
  
 %note: if frequency changes --> power must be scaled as well