% General Configurations

%% run in this order:
% 1. Shell_run.m
% 2.err_PE_MSBtoLSB_rate.m
% 3.plot_error_rate.m
% 4.matMulerrApp.m
% 5.check_data_V2.m


clear;clc
addpath([pwd '/HspiceToolbox/'])
addpath(genpath([pwd '/System_Simulations/']));
addpath(genpath([pwd '/HSPICE_Simulations/']));
%[~,cmdOUT] = system('source /usr/local/contrib/eda_tools_setup.bash','-echo') %set-up HSPICE in server first

% system level matrix multiply to generate and find the unique stimuli, produce hspice feedable data 

PrintFlag = 1;
defSHELL = 1;
CLOCK_PERIOD_ns = 3.5*10^-9;  
CLOCK_PERIOD_Lenghth = 150; % number of data point in each clock period; in lower frequencies it is better to increase number of data points of a clock period
TIME_STEP = (CLOCK_PERIOD_ns)./CLOCK_PERIOD_Lenghth ; % all clocks are 50 data point length
Vdd = .7;
Temprature = 35;
Number_of_test_data = 100;
seed = 1;  
SET_UP_TIME_percent = 10/100;%  percentage from clock period; sample SET_UP_TIME points (roughly (clock_preiod*SET_UP_TIME_percent) seconds), before next clock edge, this variable can provide a nobe to check circuit response to different frequencies
variation_percent = 0.000;% 
SPICE_input_Data_Path = [pwd '/HSPICE_Simulations/spiceModel/Pulses.SP'];
SPICE_output_Path = [pwd '/HSPICE_Simulations/'];
SPICE_output_Data= [pwd '/HSPICE_Simulations/Vdd' num2str(Vdd) 'ADDMUL_driven_final.tr0'];
[HSPICE_INPUT_DATA] = random_data_HSPICE(Number_of_test_data,PrintFlag);
generateSpiceData(HSPICE_INPUT_DATA,TIME_STEP,CLOCK_PERIOD_Lenghth,Vdd,SPICE_input_Data_Path);

% Invoke HSPICE 
        % set Vdd in HSPICE script; run simulation in terminal,etc.
disp('Running HSPICE simulation...');
SPICE_Model_Path = ' ./HSPICE_Simulations/spiceModel/ADDMUL_driven_final.SP ' ;
Output_Path = [' ./HSPICE_Simulations/' 'Vdd' num2str(Vdd) 'ADDMUL_driven_final.lis '];
HSPICE_Path = ' /usr/local/contrib/synopsys/hspice_vP-2019.06-SP2-1/hspice/P-2019.06-SP2-1/hspice/linux64/hspice ';
HSPICE_PARAMs = ' -mt 24 -hpp';
setup_SPICE_model(SPICE_Model_Path,Vdd,Temprature); %create/modify SPICE model to our simulation parameters
Command = [HSPICE_Path ' -i ' SPICE_Model_Path ' -o ' Output_Path HSPICE_PARAMs];
[~,cmdOUT] = system(Command,'-echo');

if (isempty(cmdOUT))
    disp('error in running HSPICE');
    return ;
end

%% Check data intergrity and extract faulty results from HSPICE output
variation_percent = 10;% 10%
[ResultList1,~,~] = check_data(SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList2,~,~] = check_data(SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList3,~,~] = check_data(SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList4,~,~] = check_data(SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList5,~,~] = check_data(SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);



Result.MulIn1 = [ResultList1.MulIn1, ResultList2.MulIn1 , ResultList3.MulIn1 , ResultList4.MulIn1 , ResultList5.MulIn1 ];
Result.MulIn2 = [ResultList1.MulIn2, ResultList2.MulIn2, ResultList3.MulIn2 , ResultList4.MulIn2 , ResultList5.MulIn2 ];
Result.FeedAcc = [ResultList1.FeedAcc, ResultList2.FeedAcc, ResultList3.FeedAcc , ResultList4.FeedAcc , ResultList5.FeedAcc ];
Result.Product = [ResultList1.Product, ResultList2.Product, ResultList3.Product , ResultList4.Product , ResultList5.Product ];
Result.GoldenProduct = [ResultList1.GoldenProduct, ResultList2.GoldenProduct, ResultList3.GoldenProduct , ResultList4.GoldenProduct , ResultList5.GoldenProduct ];
Result.SumHSPICE = [ResultList1.SumHSPICE, ResultList2.SumHSPICE, ResultList3.SumHSPICE , ResultList4.SumHSPICE , ResultList5.SumHSPICE ];
Result.GoldenSum = [ResultList1.GoldenSum, ResultList2.GoldenSum , ResultList3.GoldenSum , ResultList4.GoldenSum , ResultList5.GoldenSum ];

%faultsList = clean_faultsList(faultsList); %removes all zero enteries

