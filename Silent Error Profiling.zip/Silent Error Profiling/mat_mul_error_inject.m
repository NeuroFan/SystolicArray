    tic
    clear;
    clc;
    N = 1000;
    arr_ABFT = zeros(N,1);
    arr_Real = zeros(N,1);
    Mat_Size = 8;
    ColCHK = zeros(Mat_Size,N);
    counter = 0;

    parfor i = 1:N %possible race condition, check later
        err_rates = 1*[0 0 0 0 0, 0 0 0 0 0, 0 0 0 0 0, 0.0 0.0 0.0 0.5];%LSB...MSB  
        [C,Cerr] =  Matrix_Mul_With_Errors(Mat_Size, err_rates);
        [arr_ABFT(i),~] = ABFTError(Cerr);
        arr_Real(i) = sum(abs(C(:)-Cerr(:)))>0;

    %     if arr_ABFT(i) ~= arr_Real(i)
    %         counter = counter + 1;
    %     end
    end
    toc
    disp(['Total number of ABFT detected Errors ' num2str(sum(arr_ABFT))])
    disp(['Total number of existing  Errors ' num2str(sum(arr_Real))])
    disp(['Total number of silent Errors ' num2str(sum(arr_Real)- sum(arr_ABFT))])
