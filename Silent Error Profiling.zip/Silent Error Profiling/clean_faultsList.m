function removed_zeros = clean_faultsList(faultsList)
 N = length(faultsList.MulIn1);
     i_s = [];
     counter=1;
      for i = 1:N
         ALL_ZERO = faultsList.MulIn1(i) + faultsList.MulIn2(i) + faultsList.Product(i) + faultsList.FeedAcc(i) + faultsList.SumHSPICE(i);
         if (ALL_ZERO == 0)
               i_s(counter) = i; 
               counter = counter +1 ;
         end
      end
     
         faultsList.MulIn1(i_s) = [];
         faultsList.MulIn2(i_s) = [];
         faultsList.Product(i_s) = [];
         faultsList.FeedAcc(i_s) = [];
         faultsList.SumHSPICE(i_s) = [];
         faultsList.GoldenProduct(i_s) = [];
         faultsList.GoldenSum(i_s) = [];
         removed_zeros = faultsList;
     

end