function pErr = inject_error(CurrentBits,err_rates)
    N = length(err_rates);
    bin = de2bi(CurrentBits,N);
    for i = 1:N
        InjectErr = rand<err_rates(i);
        Bit = bin(i)>0;
        if InjectErr==1
           Bit = ~Bit;%randi([0 1],1); %choose randomly
        end
        bin(i) = Bit;
    end
    pErr= bi2de(bin);
end