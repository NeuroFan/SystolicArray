function [C,Cerr] =  Matrix_Mul_With_Errors(MATRIX_SIZE, error_rates)
   
  

    N = MATRIX_SIZE; %matrix size N*N
    factor = 32;
    A = factor*randi([1 4],N,N);    
    B = factor*randi([1 4],N,N);   
    C = zeros(N+1,N+1);
    Cerr = C;


    [Ac,Ar,Af] = mat_ext(A);
    [Bc,Br,Bf] = mat_ext(B);
    ArScale=Ar;BcScale = Bc;
    ArScale(end,:) = Ar(end,:)./factor; %Scale down checksum to accomodate it into 8 bits
    BcScale(:,end) = Bc(:,end)./factor; %Scale down checksum to accomodate it into 8 bits

    indx=1;

    for i = 1:N+1
        for j = 1:N+1
            for k = 1:N

                p = ArScale(i,k)*BcScale(k,j);             
                C(i,j) = C(i,j) + p;
                pErr = inject_error(p,error_rates);
                Cerr(i,j) = Cerr(i,j) + pErr;

                indx=indx+1;
            end
        end
    end
    
