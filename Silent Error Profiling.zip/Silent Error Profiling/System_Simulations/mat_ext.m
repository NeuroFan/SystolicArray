function [A_col_ext,A_row_ext,A_both_ext] = mat_ext(A)
    
   [m, n] = size(A);
   sum_col = zeros(m,1);
   sum_row = zeros(1,n);
   for i=1:m
       sum_col(i) = sum(A(i,:));
   end
   
   for i = 1:n
       sum_row(i) = sum(A(:,i));
   end
   
   S  = sum(sum(A));
   
   A_row_ext = [A;sum_row];
   A_col_ext = [A,sum_col];
   A_both_ext= [A_row_ext,[sum_col;S]];
       
end