% function [Power,PeakPower] = measurePower(allWaves, Voltage)
%  Current  = allWaves(2).data;
%  Current = resample(Current,allWaves(1).data,'linear');
%  Power = mean(abs(Current)) * Voltage;
%  PeakPower = max(abs(Current)) * Voltage;
%  

function [Power,peak] = measurePower (SPICE_output_Path,Vdd)
    
    peak =0;
    FileName = [SPICE_output_Path 'Vdd' num2str(Vdd) 'ADDMUL_driven_final.lis'];
    fid = fopen(FileName, 'r');
    if fid == -1
        error('Cannot open file: %s', FileName);
    end
    key    = ' ivdd= ';
    data   = 'not found';
    ready  = false;
    lineNo = 0;   
    while (~feof(fid) && ~ready)
        S = fgetl(fid);
        lineNo = lineNo + 1;  
        if any(strfind(S, key))
           data  = S(length(key):end);
           ready = true;
        end
    end
    fclose(fid);
    SPICE_AVG_CURRENT = str2num(data);
    Power = abs(SPICE_AVG_CURRENT * Vdd);
end
