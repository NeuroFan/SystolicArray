function f_clk = estimate_f_clk(vdd) 
% look up table based on TT HSPICE simulations to determine next clock
% frequency when we enounter an error
       x = vdd;
       
       a1 =   2.843e+09  ;%(-7.363e+14, 7.363e+14)
       b1 =       4.458  ;%(-5.392e+04, 5.393e+04)
       c1 =      -1.799  ;%(-3.226e+04, 3.226e+04)
       a2 =   2.508e+09  ;%(-7.359e+14, 7.359e+14)
       b2 =       4.891  ;%(-6.683e+04, 6.684e+04)
       c2 =       1.084  ;%(-3.985e+04, 3.985e+04)
       a3 =   1.074e+08  ;%(-4.478e+11, 4.48e+11)
       b3 =       10.17  ;%(-5385, 5406)
       c3 =       7.406  ;%(-3149, 3164)
       a4 =   5.437e+06  ;%(-1.233e+08, 1.342e+08)
       b4 =       28.97  ;%(-69.27, 127.2)
       c4 =       2.455  ;%(-57.36, 62.27)
       
       f_clk =  a1*sin(b1*x+c1) + a2*sin(b2*x+c2) + a3*sin(b3*x+c3) + a4*sin(b4*x+c4) ;%
       

end