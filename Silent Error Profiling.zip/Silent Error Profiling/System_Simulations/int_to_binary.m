function binary_array =  int_to_binary(integer, NumberOfBits)
% LSB to MSB
x = dec2bin(integer,NumberOfBits);
binary_array=zeros(1,NumberOfBits);
for i = 1:NumberOfBits
    binary_array(NumberOfBits-i+1) = bin2dec(x(i)); %the indices are in this way to force LSB to be on strat rather than end
end
end