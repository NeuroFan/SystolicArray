function powerFlipFlops = flipFlops_pwr(Vdd,f)
    disp('warning: No simulation data for flip flops');
    f = f/10^6 ; % normalize to MHz
    p_0_9v = 2.3 * 10^(-9) ;% 0.1uW/MHz
    powerFlipFlops =p_0_9v * (Vdd/0.9)^2 * f;
end