function returnStruct = adjustData(XSP,Range)
                returnStruct = struct('CLK',0,'S0',0,'S1',0,'S2',0,'S3',0,'S4',0,'S5',0,'S6',0,'S7',0,'S8',0,'S9',0,'S10',0,...
                                        'S11',0,'S12',0,'S13',0,'S14',0,'S15',0,'S16',0,'S17',0,'S18',0,'S19',0,'S20',0,'S21',0,'S22',0,'S23',0,...
                                        'A0',0,'A1',0,'A2',0,'A3',0,'A4',0,'A5',0,'A6',0,'A7',0,'B',0,'B0',0,'B1',0,'B2',0,'B3',0,'B4',0,'B5',0,'B6',0,'B7',0,...
                                        'F0',0,'F1',0,'F2',0,'F3',0,'F4',0,'F5',0,'F6',0,'F7',0,'F8',0,'F9',0,'F10',0,...
                                        'F11',0,'F12',0,'F13',0,'F14',0,'F15',0,'F16',0,'F17',0,'F18',0,'F19',0,'F20',0,'F21',0,'F22',0,'F23',0,...
                                        'P0',0,'P1',0,'P2',0,'P3',0,'P4',0,'P5',0,'P6',0,'P7',0,'P8',0,'P9',0,'P10',0,...
                                        'P11',0,'P12',0,'P13',0,'P14',0,'P15',0);
                                    
                time = XSP(1).data(Range); %better option is evalsig(x,'Time')
                returnStruct.Current  = XSP(2).data(Range);
                returnStruct.CLK  = XSP(1+2).data(Range);
                returnStruct.S0   = XSP(1+3).data(Range);
                returnStruct.S1   = XSP(1+4).data(Range);
                returnStruct.S2   = XSP(1+5).data(Range);
                returnStruct.S3   = XSP(1+6).data(Range); 
                returnStruct.S4   = XSP(1+7).data(Range);
                returnStruct.S5   = XSP(1+8).data(Range);
                returnStruct.S6   = XSP(1+9).data(Range);  
                returnStruct.S7   = XSP(1+10).data(Range);
                returnStruct.S8    =  XSP(1+11).data(Range);
                returnStruct.S9    =  XSP(1+12).data(Range);
                returnStruct.S10   =  XSP(1+13).data(Range);
                returnStruct.S11   =  XSP(1+14).data(Range);
                returnStruct.S12   =  XSP(1+15).data(Range);
                returnStruct.S13   =  XSP(1+16).data(Range);
                returnStruct.S14   =  XSP(1+17).data(Range);
                returnStruct.S15   =  XSP(1+18).data(Range);
                returnStruct.S16   =  XSP(1+19).data(Range);
                returnStruct.S17   =  XSP(1+20).data(Range);
                returnStruct.S18   =  XSP(1+21).data(Range);
                returnStruct.S19   =  XSP(1+22).data(Range);
                returnStruct.S20   =  XSP(1+23).data(Range);
                returnStruct.S21   =  XSP(1+24).data(Range);
                returnStruct.S22   =  XSP(1+25).data(Range);
                returnStruct.S23   =  XSP(1+26).data(Range);
                %disp("S is read");

                returnStruct.A0   = XSP(1+27).data(Range);
                returnStruct.A1   = XSP(1+28).data(Range);
                returnStruct.A2   = XSP(1+29).data(Range);
                returnStruct.A3   = XSP(1+30).data(Range);
                returnStruct.A4   = XSP(1+31).data(Range);
                returnStruct.A5   = XSP(1+32).data(Range);
                returnStruct.A6   = XSP(1+33).data(Range);
                returnStruct.A7   = XSP(1+34).data(Range);
                %disp("A is read");

                returnStruct.B0   = XSP(1+35).data(Range);
                returnStruct.B1   = XSP(1+36).data(Range);
                returnStruct.B2   = XSP(1+37).data(Range);
                returnStruct.B3   = XSP(1+38).data(Range);
                returnStruct.B4   = XSP(1+39).data(Range);
                returnStruct.B5   = XSP(1+40).data(Range);
                returnStruct.B6   = XSP(1+41).data(Range);
                returnStruct.B7   = XSP(1+42).data(Range);
                %disp("B is read");

                returnStruct.F0   = XSP(1+43).data(Range);
                returnStruct.F1   = XSP(1+44).data(Range);
                returnStruct.F2   = XSP(1+45).data(Range);
                returnStruct.F3   = XSP(1+46).data(Range);
                returnStruct.F4   = XSP(1+47).data(Range);
                returnStruct.F5   = XSP(1+48).data(Range);
                returnStruct.F6   = XSP(1+49).data(Range);
                returnStruct.F7   = XSP(1+50).data(Range);
                returnStruct.F8   = XSP(1+51).data(Range);
                returnStruct.F9   = XSP(1+52).data(Range);
                returnStruct.F10   = XSP(1+53).data(Range);
                returnStruct.F11   = XSP(1+54).data(Range);
                returnStruct.F12   = XSP(1+55).data(Range);
                returnStruct.F13   = XSP(1+56).data(Range);
                returnStruct.F14   = XSP(1+57).data(Range);
                returnStruct.F15   = XSP(1+58).data(Range);
                returnStruct.F16   = XSP(1+59).data(Range);
                returnStruct.F17   = XSP(1+60).data(Range);
                returnStruct.F18   = XSP(1+61).data(Range);
                returnStruct.F19   = XSP(1+62).data(Range);
                returnStruct.F20   = XSP(1+63).data(Range);
                returnStruct.F21   = XSP(1+64).data(Range);
                returnStruct.F22   = XSP(1+65).data(Range);
                returnStruct.F23   = XSP(1+66).data(Range);
                %disp("F is read");


                returnStruct.P0   = XSP(1+67).data(Range);
                returnStruct.P1   = XSP(1+68).data(Range);
                returnStruct.P2   = XSP(1+69).data(Range);
                returnStruct.P3   = XSP(1+70).data(Range);
                returnStruct.P4   = XSP(1+71).data(Range);
                returnStruct.P5   = XSP(1+72).data(Range);
                returnStruct.P6   = XSP(1+73).data(Range);
                returnStruct.P7   = XSP(1+74).data(Range);
                returnStruct.P8   = XSP(1+75).data(Range);
                returnStruct.P9   = XSP(1+76).data(Range);
                returnStruct.P10   = XSP(1+77).data(Range);
                returnStruct.P11   = XSP(1+78).data(Range);
                returnStruct.P12   = XSP(1+79).data(Range);
                returnStruct.P13   = XSP(1+80).data(Range);
                returnStruct.P14   = XSP(1+81).data(Range);
                returnStruct.P15   = XSP(1+82).data(Range);
                %disp("P is read");


                % Nonunifortm (vs time) output of hspice must be converted into uniform sampled data(STEP:(iteration+1)*STEP)
                %returnStruct.Current = resample(returnStruct.Current,time,'linear');
                returnStruct.CLK = resample(returnStruct.CLK,time,'linear');

                returnStruct.A0 = resample(returnStruct.A0,time,'linear');
                returnStruct.A1 = resample(returnStruct.A1,time,'linear');
                returnStruct.A2 = resample(returnStruct.A2,time,'linear');
                returnStruct.A3 = resample(returnStruct.A3,time,'linear');
                returnStruct.A4 = resample(returnStruct.A4,time,'linear');
                returnStruct.A5 = resample(returnStruct.A5,time,'linear');
                returnStruct.A6 = resample(returnStruct.A6,time,'linear');
                returnStruct.A7 = resample(returnStruct.A7,time,'linear');
                %disp("A is adjusted");


                returnStruct.B0 = resample(returnStruct.B0,time,'linear');
                returnStruct.B1 = resample(returnStruct.B1,time,'linear');
                returnStruct.B2 = resample(returnStruct.B2,time,'linear');
                returnStruct.B3 = resample(returnStruct.B3,time,'linear');
                returnStruct.B4 = resample(returnStruct.B4,time,'linear');
                returnStruct.B5 = resample(returnStruct.B5,time,'linear');
                returnStruct.B6 = resample(returnStruct.B6,time,'linear');
                returnStruct.B7 = resample(returnStruct.B7,time,'linear');
                %disp("B is adjusted");

                returnStruct.S0 = resample(returnStruct.S0,time,'linear');
                returnStruct.S1 = resample(returnStruct.S1,time,'linear');
                returnStruct.S2 = resample(returnStruct.S2,time,'linear');
                returnStruct.S3 = resample(returnStruct.S3,time,'linear');
                returnStruct.S4 = resample(returnStruct.S4,time,'linear');
                returnStruct.S5 = resample(returnStruct.S5,time,'linear');
                returnStruct.S6 = resample(returnStruct.S6,time,'linear');
                returnStruct.S7 = resample(returnStruct.S7,time,'linear');
                returnStruct.S8 = resample(returnStruct.S8,time,'linear');
                returnStruct.S9 = resample(returnStruct.S9,time,'linear');
                returnStruct.S10 = resample(returnStruct.S10,time,'linear');
                returnStruct.S11 = resample(returnStruct.S11,time,'linear');
                returnStruct.S12 = resample(returnStruct.S12,time,'linear');
                returnStruct.S13 = resample(returnStruct.S13,time,'linear');
                returnStruct.S14 = resample(returnStruct.S14,time,'linear');
                returnStruct.S15 = resample(returnStruct.S15,time,'linear');
                returnStruct.S16 = resample(returnStruct.S16,time,'linear');
                returnStruct.S17 = resample(returnStruct.S17,time,'linear');
                returnStruct.S18 = resample(returnStruct.S18,time,'linear');
                returnStruct.S19 = resample(returnStruct.S19,time,'linear');
                returnStruct.S20 = resample(returnStruct.S20,time,'linear');
                returnStruct.S21 = resample(returnStruct.S21,time,'linear');
                returnStruct.S22 = resample(returnStruct.S22,time,'linear');
                returnStruct.S23 = resample(returnStruct.S23,time,'linear');
                %disp("S is adjusted");


                returnStruct.F0 = resample(returnStruct.F0,time,'linear');
                returnStruct.F1 = resample(returnStruct.F1,time,'linear');
                returnStruct.F2 = resample(returnStruct.F2,time,'linear');
                returnStruct.F3 = resample(returnStruct.F3,time,'linear');
                returnStruct.F4 = resample(returnStruct.F4,time,'linear');
                returnStruct.F5 = resample(returnStruct.F5,time,'linear');
                returnStruct.F6 = resample(returnStruct.F6,time,'linear');
                returnStruct.F7 = resample(returnStruct.F7,time,'linear');
                returnStruct.F8 = resample(returnStruct.F8,time,'linear');
                returnStruct.F9 = resample(returnStruct.F9,time,'linear');
                returnStruct.F10 = resample(returnStruct.F10,time,'linear');
                returnStruct.F11 = resample(returnStruct.F11,time,'linear');
                returnStruct.F12 = resample(returnStruct.F12,time,'linear');
                returnStruct.F13 = resample(returnStruct.F13,time,'linear');
                returnStruct.F14 = resample(returnStruct.F14,time,'linear');
                returnStruct.F15 = resample(returnStruct.F15,time,'linear');
                returnStruct.F16 = resample(returnStruct.F16,time,'linear');
                returnStruct.F17 = resample(returnStruct.F17,time,'linear');
                returnStruct.F18 = resample(returnStruct.F18,time,'linear');
                returnStruct.F19 = resample(returnStruct.F19,time,'linear');
                returnStruct.F20 = resample(returnStruct.F20,time,'linear');
                returnStruct.F21 = resample(returnStruct.F21,time,'linear');
                returnStruct.F22 = resample(returnStruct.F22,time,'linear');
                returnStruct.F23 = resample(returnStruct.F23,time,'linear');
                %disp("F is adjusted");


                returnStruct.P0 = resample(returnStruct.P0,time,'linear');
                returnStruct.P1 = resample(returnStruct.P1,time,'linear');
                returnStruct.P2 = resample(returnStruct.P2,time,'linear');
                returnStruct.P3 = resample(returnStruct.P3,time,'linear');
                returnStruct.P4 = resample(returnStruct.P4,time,'linear');
                returnStruct.P5 = resample(returnStruct.P5,time,'linear');
                returnStruct.P6 = resample(returnStruct.P6,time,'linear');
                returnStruct.P7 = resample(returnStruct.P7,time,'linear');
                returnStruct.P8 = resample(returnStruct.P8,time,'linear');
                returnStruct.P9 = resample(returnStruct.P9,time,'linear');
                returnStruct.P10 = resample(returnStruct.P10,time,'linear');
                returnStruct.P11 = resample(returnStruct.P11,time,'linear');
                returnStruct.P12 = resample(returnStruct.P12,time,'linear');
                returnStruct.P13 = resample(returnStruct.P13,time,'linear');
                returnStruct.P14 = resample(returnStruct.P14,time,'linear');
                returnStruct.P15 = resample(returnStruct.P15,time,'linear');
                %disp("P is adjusted");
end