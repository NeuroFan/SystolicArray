function decimal = binary_to_decimal(bit_array)
%note the order is from LSB to MSB
NumberOfBits = length(bit_array);
binary_char_form(1:NumberOfBits) = ' ';
for i = 1:NumberOfBits
    binary_char_form(NumberOfBits-i+1) = dec2bin(bit_array(i));
end
decimal = bin2dec(binary_char_form);