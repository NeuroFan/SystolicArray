function setup_SPICE_model(SPICE_Model_Path,Vdd,Temprature)
    std = fileread('RESET_OF_FILE.txt');
    SPICE_Model_Path = strtrim(SPICE_Model_Path);
    [file,errorMsg] = fopen(SPICE_Model_Path, 'wt' );
    fprintf( file, '***************************************************************************************  \n');
    fprintf( file, 'Vdd     dd      ss	dc= %f *matlab changes this value autmatically  \n',Vdd);
    fprintf( file, 'Vss	ss      0	dc=0 \n');
    fprintf( file, ".lib './Tech90nm/MOSFET_HSPICE_MODEL/L90_SP10_V051.lib' tt  \n");
    
    fprintf( file, '.temp %d  \n',Temprature);
    fprintf(file,'%s\n\n',std);
end
