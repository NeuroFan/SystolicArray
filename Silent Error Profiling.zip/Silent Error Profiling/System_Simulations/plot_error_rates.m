
for i = 1:1:22 %from LSB to 22th bit
    plot((1:25),BitErr(i,1:25))
    hold on
end