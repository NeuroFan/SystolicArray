% power vs matrix size @0.6v and f = 200MHz
function power_vs_size(PE_pwr,regs_pwr,ABFT_Overhead)
NM = 8:256;
Power = (((NM.^2+NM)*(PE_pwr+regs_pwr) + NM.*ABFT_Overhead )./(NM.^2))*10^6
plot(NM,Power)