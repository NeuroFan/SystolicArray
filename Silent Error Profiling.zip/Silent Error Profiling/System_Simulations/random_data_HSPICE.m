function [HSPICE_DATA]=  random_data_HSPICE(N,PrintFlag)
   
    
   
  A = randi([1 1],N,1);
  B = randi([1 1],N,1);
  F = randi([2^23-1 2^23-1],N,1);
  
  transientData = [A,B,F];% p(i) = a(i)*b(i) + p(i-1); --> [a(i),b(i),p(i-1),p(i)]

  Uniq_Combinations_of_inputs = transientData;%unique(transientData,'rows'); %this removes reapted computations
    Len_Comb = length(Uniq_Combinations_of_inputs);
    timeToSimulate = 10*Len_Comb./(2^16);  %2^16 bit simulation took around 10 hours 
    if PrintFlag==1
    disp(['Estimated simulation time: ~' num2str(round(timeToSimulate)) ' hours(' num2str(round(timeToSimulate*60))  'minutes) for ' num2str(Len_Comb) ' unique data points' ]);
    end
    %% Convert generated data into HSPICE readable (binary array)
     HSPICE_DATA  = zeros(2*Len_Comb, 8+8+24); % 2 8bits for mul and 1 24bit for adder
     j = 0;
     for i = 1:Len_Comb
             mul_in1 = Uniq_Combinations_of_inputs(i,1);
             mul_in2 = Uniq_Combinations_of_inputs(i,2);
             add_in1 = Uniq_Combinations_of_inputs(i,3);
             HSPICE_DATA(j+1,1:8) = int_to_binary(mul_in1,8);
             HSPICE_DATA(j+1,9:16) = int_to_binary(mul_in2,8);
             HSPICE_DATA(j+1,17:40) = int_to_binary(add_in1,24); % NOTICE 32 bit is really needed!!!! but we used 24 bit should be corrected later!

                     
             HSPICE_DATA(j+2,1:8) = int_to_binary(0,8);
             HSPICE_DATA(j+2,9:16) = int_to_binary(0,8);
             HSPICE_DATA(j+2,17:40) = int_to_binary(0,24); 
             j=j+2;
     end
     %% Control if generated data is correct
     % data might not match due to dec2bin's second argument that limits number
     % of bits
     %misMatch = 0;
%      for i = 1:length(HSPICE_DATA)
% 
%          M1_dec = binary_to_decimal( HSPICE_DATA(i,1:8));
%          M2_dec = binary_to_decimal(HSPICE_DATA(i,9:16));
%          A1_dec = binary_to_decimal(HSPICE_DATA(i,17:40));
% 
%          if (M1_dec ~= Uniq_Combinations_of_inputs(i,1))|(M2_dec ~=Uniq_Combinations_of_inputs(i,2))|(A1_dec ~=Uniq_Combinations_of_inputs(i,3))
%              if PrintFlag==1
%              disp("Error Generated binary does NOT matche MATLAB!");
%              end
%              misMatch = 1;
%              break
%          end
%      end
%      if (misMatch==0)
%          if PrintFlag==1
%          disp("Success!");
%          end
%      end
end
