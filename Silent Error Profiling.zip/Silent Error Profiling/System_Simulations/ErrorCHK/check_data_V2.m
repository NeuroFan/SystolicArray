function [Results,XSP,clk_period] = check_data_V2(resampledData,SPICE_output_Data_Path,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd,variation_percent,PrintFlag)
            
XSP =1;
             inDataIdx =0;
            
            Vth = 0.6*Vdd;
            Results = struct('MulIn1',zeros(1,2),'MulIn2',zeros(1,2),'FeedAcc',zeros(1,2),'Product',zeros(1,2),'GoldenProduct',zeros(1,2),'SumHSPICE',zeros(1,2),'GoldenSum',zeros(1,2));
          

       
            
                    % find rising edges 

                    edge = zeros(size(resampledData.CLK));
                    L = length(resampledData.CLK);

                    for i = 2:L
                        if (resampledData.CLK(i-1)<0.01 && resampledData.CLK(i)>0.01) %assiming no noise on floor
                            edge(i) = 1;
                        end
                    end

                    edge_pos = find(edge==1,10,'first');
                    first_edge = edge_pos(1);
                    second_edge = edge_pos(2);

                    clk_period = edge_pos(2)-edge_pos(1);

                    % Check data(STEP:2*STEP) on the rising edges, extract look-up tables for different frequencies

                    previouse_edge = first_edge;
                

                    delay = 20; % sampling of input occurs a bit after clock edge; stimulation signals have some delay rising time compared to clock
                    setup_hold_time =round(SET_UP_TIME_percent * clk_period); % sampling of output should occur a bit before clock edge
                    
                    %%% In hspice simulation the 0.5t delay for A signal must be removed
                    %%% otherwise it generates mismath on some inputs
                    Count = 0;
                    misCount = 0;
                    input_signala_mismatch_count = 0;

                    for current = second_edge:L %start from second edge and check if the data(STEP:2*STEP) generated on prevoiuse edge resutled in correct operation
                        if edge(current)==1 %if we are on an edge

                           inDataIdx = inDataIdx +1 ;
                           inp_smp_idx = previouse_edge+delay; % this "delay" is not setup/hold time; this is because of slop in rising that HSPICE adds to input and clock signals
                           Idx = inp_smp_idx;
                           A = vector_bin_8_bits(resampledData.A7(Idx),resampledData.A6(Idx),...
                                                  resampledData.A5(Idx),resampledData.A4(Idx),...
                                                  resampledData.A3(Idx),resampledData.A2(Idx),...
                                                  resampledData.A1(Idx),resampledData.A0(Idx),Vth);

                           B = vector_bin_8_bits(resampledData.B7(Idx),resampledData.B6(Idx),...
                                                 resampledData.B5(Idx),resampledData.B4(Idx),...
                                                 resampledData.B3(Idx),resampledData.B2(Idx),...
                                                 resampledData.B1(Idx),resampledData.B0(Idx),Vth);
                           F = vector_bin_24_bits(resampledData.F23(Idx),resampledData.F22(Idx),resampledData.F21(Idx),resampledData.F20(Idx),resampledData.F19(Idx),resampledData.F18(Idx),...
                               resampledData.F17(Idx),resampledData.F16(Idx),resampledData.F15(Idx),resampledData.F14(Idx),resampledData.F13(Idx),resampledData.F12(Idx),...
                               resampledData.F11(Idx),resampledData.F10(Idx),resampledData.F9(Idx),resampledData.F8(Idx),resampledData.F7(Idx),resampledData.F6(Idx),resampledData.F5(Idx),...
                               resampledData.F4(Idx),resampledData.F3(Idx),resampledData.F2(Idx),resampledData.F1(Idx),resampledData.F0(Idx),Vth);
                           
                           

                           A_mat = binary_to_decimal(HSPICE_INPUT_DATA(inDataIdx,1:8));
                           B_mat = binary_to_decimal(HSPICE_INPUT_DATA(inDataIdx,9:16));
                           F_mat = binary_to_decimal(HSPICE_INPUT_DATA(inDataIdx,17:40));
                           
                           
                            if (A_mat ~= A)||(B_mat ~= B) || (F_mat ~=F) %input mismatch chk
                                %disp ("A = "+num2str(A)+" Matlab: "+num2str(A_MAT) + "   B = "+num2str(B)+" Matlab: "+num2str(B_MAT)); 
                                disp("mismatch of inputs"); % this is serious warning, do not turn off
                                input_signala_mismatch_count = input_signala_mismatch_count+1;
                            end

                           VARIATION = round( (rand-0.3)*setup_hold_time*variation_percent);
                           outp_smp_inx = current - (setup_hold_time + VARIATION);
                           Idx = outp_smp_inx;
                           
                           P = vector_bin_24_bits(0,0,0,0,0,0,0,0,resampledData.P15(Idx),resampledData.P14(Idx),resampledData.P13(Idx),resampledData.P12(Idx),resampledData.P11(Idx),resampledData.P10(Idx),resampledData.P9(Idx),resampledData.P8(Idx),resampledData.P7(Idx),resampledData.P6(Idx),resampledData.P5(Idx),resampledData.P4(Idx),resampledData.P3(Idx),resampledData.P2(Idx),resampledData.P1(Idx),resampledData.P0(Idx),Vth);
                           S_sim = vector_bin_24_bits(resampledData.S23(Idx),resampledData.S22(Idx),resampledData.S21(Idx),resampledData.S20(Idx),resampledData.S19(Idx),resampledData.S18(Idx),resampledData.S17(Idx),resampledData.S16(Idx),resampledData.S15(Idx),resampledData.S14(Idx),resampledData.S13(Idx),resampledData.S12(Idx),resampledData.S11(Idx),resampledData.S10(Idx),resampledData.S9(Idx),resampledData.S8(Idx),resampledData.S7(Idx),...
                               resampledData.S6(Idx),resampledData.S5(Idx),resampledData.S4(Idx),resampledData.S3(Idx),resampledData.S2(Idx),resampledData.S1(Idx),resampledData.S0(Idx),Vth);

                           S_mat = (A * B)+F  ;
                           bin_S = dec2bin(S_mat,32);        %to emulate hardware non-saturation behavior of 8-bit adder
                           S_mat = bin2dec(bin_S(end-23:end)); %note we decided 8 bit output, it can be extended of course
                            
                               if (S_sim~=S_mat) && (PrintFlag==1)
                                disp("Simulation result does not match!");
                                disp(num2str(S_sim)+ " "+num2str(S_mat));
                                misCount=misCount+1;
                               end 
                                % record the input/outputs of faulty results
                               Results.MulIn1(Count+1) = A;
                               Results.MulIn2(Count+1) = B;
                               Results.Product(Count+1)= P;
                               Results.FeedAcc(Count+1) =F;
                               Results.SumHSPICE(Count+1)=S_sim;
                               Results.GoldenSum(Count+1)=S_mat;
                               Results.GoldenProduct(Count+1)=(A * B);

                               
                               Count = Count+1;
                            

                           previouse_edge = current;

                        end
                    end

                    if ((input_signala_mismatch_count==0) && (misCount == 0))
                        if PrintFlag==1
                        disp("Perfect Match!");
                        end
                    else
                        if PrintFlag==1
                        disp("Error: mis-match!");
                        disp("input_signala_mismatch_count: "+input_signala_mismatch_count);
                        disp("output_signal_mismatch_count: "+misCount);
                        disp("Total operations :"+sum(edge));
                        end
                    end
            end
