function [ Error_ABFT,ColumnsChecks] = ABFTError(Mat_Mul)
 
    Last_Column_Sum = Mat_Mul(1:end,end);
    Computed_Sum = sum(Mat_Mul(1:end,1:end-1), 2)./32;
    
    Comparison = Last_Column_Sum~= Computed_Sum;
    ColumnsChecks = Comparison(:)';
    Error_ABFT = sum(Comparison(:))>0;
end
