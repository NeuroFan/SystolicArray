echo "MATLAB and HSPICE required"
echo "Modify the following according to your system's settings"

# Setup HSPICE simulation tool before running MATLAB
source /usr/local/contrib/eda_tools_setup.bash 


-----------------------------------------------------------------------------------------
#cmdDEFSHELL = "defSHELL = 1;"
#cmdTIME_STEP = "TIME_STEP = 0.05*10^-9;"
#cmdPERIOD = "CLOCK_PERIOD = 100; "
#cmdSIZE = "MATRIX_SIZE = 64;"
#cmdVdd = "Vdd = 0.9;"
cmdRUN = ";run ./StimuliDataGeneration//koti/msafarpo/Desktop/Integrated/Shell_Run.m;"

#COMMAND = "$cmdDEFSHELL$cmdTIME_STEP$cmdPERIOD$cmdSIZE$cmdVdd$cmdRUN"

matlab -r  "$cmdRUN"  
----------------------------------------------------------------------------------------

