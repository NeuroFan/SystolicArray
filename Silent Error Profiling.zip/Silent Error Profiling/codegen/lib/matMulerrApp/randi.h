/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: randi.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:35:08
 */

#ifndef RANDI_H
#define RANDI_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void randi(double varargin_1, double varargin_2, emxArray_real_T *r);

#endif

/*
 * File trailer for randi.h
 *
 * [EOF]
 */
