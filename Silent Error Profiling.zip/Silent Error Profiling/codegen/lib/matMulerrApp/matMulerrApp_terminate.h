/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matMulerrApp_terminate.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:35:08
 */

#ifndef MATMULERRAPP_TERMINATE_H
#define MATMULERRAPP_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void matMulerrApp_terminate(void);

#endif

/*
 * File trailer for matMulerrApp_terminate.h
 *
 * [EOF]
 */
