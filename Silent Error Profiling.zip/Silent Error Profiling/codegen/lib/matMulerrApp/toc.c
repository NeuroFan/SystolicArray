/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: toc.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:35:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "toc.h"
#include "timeKeeper.h"
#include <stdio.h>

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void toc(void)
{
  double tstart_tv_sec;
  double tstart_tv_nsec;
  struct timespec b_timespec;
  b_timeKeeper(&tstart_tv_sec, &tstart_tv_nsec);
  clock_gettime(CLOCK_MONOTONIC, &b_timespec);
  printf("Elapsed time is %f seconds\n", ((double)b_timespec.tv_sec -
          tstart_tv_sec) + ((double)b_timespec.tv_nsec - tstart_tv_nsec) /
         1.0E+9);
  fflush(stdout);
}

/*
 * File trailer for toc.c
 *
 * [EOF]
 */
