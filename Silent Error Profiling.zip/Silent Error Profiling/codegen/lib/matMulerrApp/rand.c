/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: rand.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:35:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "rand.h"
#include "eml_rand.h"

/* Function Definitions */

/*
 * Arguments    : double varargin_1
 *                double varargin_2
 *                emxArray_real_T *r
 * Return Type  : void
 */
void b_rand(double varargin_1, double varargin_2, emxArray_real_T *r)
{
  eml_rand(varargin_1, varargin_2, r);
}

/*
 * Arguments    : void
 * Return Type  : double
 */
double c_rand(void)
{
  return b_eml_rand();
}

/*
 * File trailer for rand.c
 *
 * [EOF]
 */
