/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: mat_ext.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

#ifndef MAT_EXT_H
#define MAT_EXT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void mat_ext(const emxArray_real_T *A, emxArray_real_T *A_col_ext,
                    emxArray_real_T *A_row_ext, emxArray_real_T *A_both_ext);

#endif

/*
 * File trailer for mat_ext.h
 *
 * [EOF]
 */
