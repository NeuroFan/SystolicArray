/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matMulerrApp.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

#ifndef MATMULERRAPP_H
#define MATMULERRAPP_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern int getThreadID(void);
extern void getThreadID_init(void);
extern void matMulerrApp(double N, double Mat_Size);

#endif

/*
 * File trailer for matMulerrApp.h
 *
 * [EOF]
 */
