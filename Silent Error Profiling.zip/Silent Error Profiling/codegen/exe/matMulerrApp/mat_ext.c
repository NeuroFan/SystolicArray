/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: mat_ext.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "mat_ext.h"
#include "matMulerrApp_emxutil.h"
#include "sum.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *A
 *                emxArray_real_T *A_col_ext
 *                emxArray_real_T *A_row_ext
 *                emxArray_real_T *A_both_ext
 * Return Type  : void
 */
void mat_ext(const emxArray_real_T *A, emxArray_real_T *A_col_ext,
             emxArray_real_T *A_row_ext, emxArray_real_T *A_both_ext)
{
  emxArray_real_T *sum_col;
  int i4;
  int npages;
  emxArray_real_T *sum_row;
  int i;
  int xpageoffset;
  emxArray_real_T *b_A;
  int vlen;
  emxArray_real_T *y;
  unsigned int sz_idx_1;
  int input_sizes_idx_1;
  boolean_T empty_non_axis_sizes;
  signed char sizes_idx_0;
  double d0;
  emxInit_real_T(&sum_col, 1);
  i4 = A->size[0];
  npages = sum_col->size[0];
  sum_col->size[0] = A->size[0];
  emxEnsureCapacity_real_T(sum_col, npages);
  emxInit_real_T(&sum_row, 2);
  for (i = 0; i < i4; i++) {
    xpageoffset = A->size[1];
    npages = sum_row->size[0] * sum_row->size[1];
    sum_row->size[0] = 1;
    sum_row->size[1] = xpageoffset;
    emxEnsureCapacity_real_T(sum_row, npages);
    for (npages = 0; npages < xpageoffset; npages++) {
      sum_row->data[npages] = A->data[i + A->size[0] * npages];
    }

    sum_col->data[i] = sum(sum_row);
  }

  i4 = A->size[1];
  npages = sum_row->size[0] * sum_row->size[1];
  sum_row->size[0] = 1;
  sum_row->size[1] = A->size[1];
  emxEnsureCapacity_real_T(sum_row, npages);
  emxInit_real_T(&b_A, 1);
  for (i = 0; i < i4; i++) {
    xpageoffset = A->size[0];
    npages = b_A->size[0];
    b_A->size[0] = xpageoffset;
    emxEnsureCapacity_real_T(b_A, npages);
    for (npages = 0; npages < xpageoffset; npages++) {
      b_A->data[npages] = A->data[npages + A->size[0] * i];
    }

    sum_row->data[i] = b_sum(b_A);
  }

  vlen = A->size[0];
  emxInit_real_T(&y, 2);
  if ((A->size[0] == 0) || (A->size[1] == 0)) {
    sz_idx_1 = (unsigned int)A->size[1];
    i4 = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)sz_idx_1;
    emxEnsureCapacity_real_T(y, i4);
    xpageoffset = (int)sz_idx_1;
    for (i4 = 0; i4 < xpageoffset; i4++) {
      y->data[i4] = 0.0;
    }
  } else {
    npages = A->size[1];
    i4 = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = A->size[1];
    emxEnsureCapacity_real_T(y, i4);
    for (i = 0; i < npages; i++) {
      xpageoffset = i * A->size[0];
      y->data[i] = A->data[xpageoffset];
      for (input_sizes_idx_1 = 2; input_sizes_idx_1 <= vlen; input_sizes_idx_1++)
      {
        y->data[i] += A->data[(xpageoffset + input_sizes_idx_1) - 1];
      }
    }
  }

  if ((A->size[0] != 0) && (A->size[1] != 0)) {
    vlen = A->size[1];
  } else if (sum_row->size[1] != 0) {
    vlen = sum_row->size[1];
  } else {
    vlen = A->size[1];
    if (vlen <= 0) {
      vlen = 0;
    }
  }

  empty_non_axis_sizes = (vlen == 0);
  if (empty_non_axis_sizes || ((A->size[0] != 0) && (A->size[1] != 0))) {
    xpageoffset = A->size[0];
  } else {
    xpageoffset = 0;
  }

  if (empty_non_axis_sizes || (sum_row->size[1] != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }

  input_sizes_idx_1 = xpageoffset;
  xpageoffset = sizes_idx_0;
  i4 = A_row_ext->size[0] * A_row_ext->size[1];
  A_row_ext->size[0] = input_sizes_idx_1 + sizes_idx_0;
  A_row_ext->size[1] = vlen;
  emxEnsureCapacity_real_T(A_row_ext, i4);
  for (i4 = 0; i4 < vlen; i4++) {
    for (npages = 0; npages < input_sizes_idx_1; npages++) {
      A_row_ext->data[npages + A_row_ext->size[0] * i4] = A->data[npages +
        input_sizes_idx_1 * i4];
    }
  }

  for (i4 = 0; i4 < vlen; i4++) {
    for (npages = 0; npages < xpageoffset; npages++) {
      A_row_ext->data[input_sizes_idx_1 + A_row_ext->size[0] * i4] =
        sum_row->data[sizes_idx_0 * i4];
    }
  }

  emxFree_real_T(&sum_row);
  if ((A->size[0] != 0) && (A->size[1] != 0)) {
    vlen = A->size[0];
  } else if (sum_col->size[0] != 0) {
    vlen = sum_col->size[0];
  } else {
    vlen = A->size[0];
    if (vlen <= 0) {
      vlen = 0;
    }
  }

  empty_non_axis_sizes = (vlen == 0);
  if (empty_non_axis_sizes || ((A->size[0] != 0) && (A->size[1] != 0))) {
    input_sizes_idx_1 = A->size[1];
  } else {
    input_sizes_idx_1 = 0;
  }

  if (empty_non_axis_sizes || (sum_col->size[0] != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }

  i4 = A_col_ext->size[0] * A_col_ext->size[1];
  A_col_ext->size[0] = vlen;
  A_col_ext->size[1] = input_sizes_idx_1 + sizes_idx_0;
  emxEnsureCapacity_real_T(A_col_ext, i4);
  for (i4 = 0; i4 < input_sizes_idx_1; i4++) {
    for (npages = 0; npages < vlen; npages++) {
      A_col_ext->data[npages + A_col_ext->size[0] * i4] = A->data[npages + vlen *
        i4];
    }
  }

  xpageoffset = sizes_idx_0;
  for (i4 = 0; i4 < xpageoffset; i4++) {
    for (npages = 0; npages < vlen; npages++) {
      A_col_ext->data[npages + A_col_ext->size[0] * input_sizes_idx_1] =
        sum_col->data[npages];
    }
  }

  d0 = sum(y);
  i4 = b_A->size[0];
  b_A->size[0] = sum_col->size[0] + 1;
  emxEnsureCapacity_real_T(b_A, i4);
  xpageoffset = sum_col->size[0];
  emxFree_real_T(&y);
  for (i4 = 0; i4 < xpageoffset; i4++) {
    b_A->data[i4] = sum_col->data[i4];
  }

  b_A->data[sum_col->size[0]] = d0;
  emxFree_real_T(&sum_col);
  if ((A_row_ext->size[0] != 0) && (A_row_ext->size[1] != 0)) {
    xpageoffset = A_row_ext->size[0];
  } else {
    xpageoffset = b_A->size[0];
  }

  if ((A_row_ext->size[0] != 0) && (A_row_ext->size[1] != 0)) {
    input_sizes_idx_1 = A_row_ext->size[1];
  } else {
    input_sizes_idx_1 = 0;
  }

  i4 = A_both_ext->size[0] * A_both_ext->size[1];
  A_both_ext->size[0] = xpageoffset;
  A_both_ext->size[1] = input_sizes_idx_1 + 1;
  emxEnsureCapacity_real_T(A_both_ext, i4);
  for (i4 = 0; i4 < input_sizes_idx_1; i4++) {
    for (npages = 0; npages < xpageoffset; npages++) {
      A_both_ext->data[npages + A_both_ext->size[0] * i4] = A_row_ext->
        data[npages + xpageoffset * i4];
    }
  }

  for (i4 = 0; i4 < 1; i4++) {
    for (npages = 0; npages < xpageoffset; npages++) {
      A_both_ext->data[npages + A_both_ext->size[0] * input_sizes_idx_1] =
        b_A->data[npages];
    }
  }

  emxFree_real_T(&b_A);
}

/*
 * File trailer for mat_ext.c
 *
 * [EOF]
 */
