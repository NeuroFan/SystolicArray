/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matMulerrApp_data.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
omp_nest_lock_t emlrtNestLockGlobal;

/*
 * File trailer for matMulerrApp_data.c
 *
 * [EOF]
 */
