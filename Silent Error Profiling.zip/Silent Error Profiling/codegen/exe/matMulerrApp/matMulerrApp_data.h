/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matMulerrApp_data.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

#ifndef MATMULERRAPP_DATA_H
#define MATMULERRAPP_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Variable Declarations */
extern omp_nest_lock_t emlrtNestLockGlobal;

#endif

/*
 * File trailer for matMulerrApp_data.h
 *
 * [EOF]
 */
