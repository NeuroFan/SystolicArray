/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_matMulerrApp_api.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

#ifndef _CODER_MATMULERRAPP_API_H
#define _CODER_MATMULERRAPP_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_matMulerrApp_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void matMulerrApp(real_T N, real_T Mat_Size);
extern void matMulerrApp_api(const mxArray * const prhs[2], int32_T nlhs);
extern void matMulerrApp_atexit(void);
extern void matMulerrApp_initialize(void);
extern void matMulerrApp_terminate(void);
extern void matMulerrApp_xil_shutdown(void);
extern void matMulerrApp_xil_terminate(void);

#endif

/*
 * File trailer for _coder_matMulerrApp_api.h
 *
 * [EOF]
 */
