/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matMulerrApp.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "matMulerrApp_emxutil.h"
#include "eml_rand.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "Matrix_Mul_With_Errors.h"
#include "toc.h"
#include "tic.h"

/* Variable Definitions */
static int threadID;

#pragma omp threadprivate (threadID)

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : int
 */
int getThreadID(void)
{
  return threadID;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void getThreadID_init(void)
{
  int ub_loop;
  int i;
  ub_loop = omp_get_max_threads();

#pragma omp parallel for schedule(static)\
 num_threads(omp_get_max_threads())

  for (i = 1; i <= ub_loop; i++) {
    threadID = omp_get_thread_num();
  }
}

/*
 * Arguments    : double N
 *                double Mat_Size
 * Return Type  : void
 */
void matMulerrApp(double N, double Mat_Size)
{
  int ub_loop;
  int i;
  emxArray_real_T *C;
  emxArray_real_T *Cerr;
  tic();

  /* ColCHK = zeros(Mat_Size,N); */
  ub_loop = (int)N - 1;
  if (!omp_in_parallel()) {
    c_eml_rand_mt19937ar_stateful_s(true);
    eml_rand_swap();
  }

#pragma omp parallel \
 num_threads(omp_get_max_threads()) \
 private(C,Cerr)

  {
    emxInit_real_T(&C, 2);
    emxInit_real_T(&Cerr, 2);

#pragma omp for nowait

    for (i = 0; i <= ub_loop; i++) {
      /* possible race condition, check later */
      /* LSB...MSB   */
      Matrix_Mul_With_Errors(Mat_Size, C, Cerr);

      /*      if arr_ABFT(i) ~= arr_Real(i) */
      /*          counter = counter + 1; */
      /*      end */
    }

    emxFree_real_T(&Cerr);
    emxFree_real_T(&C);
  }

  if (!omp_in_parallel()) {
    c_eml_rand_mt19937ar_stateful_s(false);
    eml_rand_swap();
  }

  toc();
}

/*
 * File trailer for matMulerrApp.c
 *
 * [EOF]
 */
