/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: Matrix_Mul_With_Errors.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

/* Include Files */
#include <float.h>
#include <math.h>
#include "rt_nonfinite.h"
#include <string.h>
#include "matMulerrApp.h"
#include "Matrix_Mul_With_Errors.h"
#include "matMulerrApp_emxutil.h"
#include "rand.h"
#include "mat_ext.h"
#include "randi.h"

/* Function Declarations */
static double rt_remd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_remd_snf(double u0, double u1)
{
  double y;
  double q;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = rtNaN;
  } else if (rtIsInf(u1)) {
    y = u0;
  } else if ((u1 != 0.0) && (u1 != trunc(u1))) {
    q = fabs(u0 / u1);
    if (fabs(q - floor(q + 0.5)) <= DBL_EPSILON * q) {
      y = 0.0 * u0;
    } else {
      y = fmod(u0, u1);
    }
  } else {
    y = fmod(u0, u1);
  }

  return y;
}

/*
 * Arguments    : double MATRIX_SIZE
 *                emxArray_real_T *C
 *                emxArray_real_T *Cerr
 * Return Type  : void
 */
void Matrix_Mul_With_Errors(double MATRIX_SIZE, emxArray_real_T *C,
  emxArray_real_T *Cerr)
{
  emxArray_real_T *BcScale;
  emxArray_real_T *b;
  int i0;
  int i1;
  int j;
  emxArray_real_T *r0;
  emxArray_real_T *ArScale;
  emxArray_real_T *Af;
  emxArray_real_T *b_ArScale;
  int i;
  int b_i;
  emxArray_real_T *b_BcScale;
  int b_j;
  int k;
  double p;
  double bin[19];
  boolean_T InjectErr;
  static const double dv0[19] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5 };

  double d;
  boolean_T Bit;
  emxInit_real_T(&BcScale, 2);
  emxInit_real_T(&b, 2);

  /* matrix size N*N */
  randi(MATRIX_SIZE, MATRIX_SIZE, BcScale);
  randi(MATRIX_SIZE, MATRIX_SIZE, b);
  i0 = C->size[0] * C->size[1];
  i1 = (int)(MATRIX_SIZE + 1.0);
  C->size[0] = i1;
  C->size[1] = i1;
  emxEnsureCapacity_real_T(C, i0);
  j = i1 * i1;
  for (i0 = 0; i0 < j; i0++) {
    C->data[i0] = 0.0;
  }

  i0 = Cerr->size[0] * Cerr->size[1];
  Cerr->size[0] = i1;
  Cerr->size[1] = i1;
  emxEnsureCapacity_real_T(Cerr, i0);
  for (i0 = 0; i0 < j; i0++) {
    Cerr->data[i0] = 0.0;
  }

  emxInit_real_T(&r0, 2);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = BcScale->size[0];
  r0->size[1] = BcScale->size[1];
  emxEnsureCapacity_real_T(r0, i0);
  j = BcScale->size[0] * BcScale->size[1];
  for (i0 = 0; i0 < j; i0++) {
    r0->data[i0] = 32.0 * BcScale->data[i0];
  }

  emxInit_real_T(&ArScale, 2);
  emxInit_real_T(&Af, 2);
  mat_ext(r0, BcScale, ArScale, Af);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = b->size[0];
  r0->size[1] = b->size[1];
  emxEnsureCapacity_real_T(r0, i0);
  j = b->size[0] * b->size[1];
  for (i0 = 0; i0 < j; i0++) {
    r0->data[i0] = 32.0 * b->data[i0];
  }

  emxInit_real_T(&b_ArScale, 2);
  mat_ext(r0, BcScale, Af, b);
  i0 = ArScale->size[0] - 1;
  j = ArScale->size[1] - 1;
  i = ArScale->size[0] - 1;
  b_i = b_ArScale->size[0] * b_ArScale->size[1];
  b_ArScale->size[0] = 1;
  b_ArScale->size[1] = j + 1;
  emxEnsureCapacity_real_T(b_ArScale, b_i);
  emxFree_real_T(&r0);
  emxFree_real_T(&b);
  emxFree_real_T(&Af);
  for (b_i = 0; b_i <= j; b_i++) {
    b_ArScale->data[b_i] = ArScale->data[i0 + ArScale->size[0] * b_i] / 32.0;
  }

  j = b_ArScale->size[1];
  for (i0 = 0; i0 < j; i0++) {
    ArScale->data[i + ArScale->size[0] * i0] = b_ArScale->data[i0];
  }

  emxFree_real_T(&b_ArScale);
  emxInit_real_T(&b_BcScale, 1);

  /* Scale down checksum to accomodate it into 8 bits */
  j = BcScale->size[0] - 1;
  i0 = BcScale->size[1] - 1;
  i = BcScale->size[1] - 1;
  b_i = b_BcScale->size[0];
  b_BcScale->size[0] = j + 1;
  emxEnsureCapacity_real_T(b_BcScale, b_i);
  for (b_i = 0; b_i <= j; b_i++) {
    b_BcScale->data[b_i] = BcScale->data[b_i + BcScale->size[0] * i0] / 32.0;
  }

  j = b_BcScale->size[0];
  for (i0 = 0; i0 < j; i0++) {
    BcScale->data[i0 + BcScale->size[0] * i] = b_BcScale->data[i0];
  }

  emxFree_real_T(&b_BcScale);

  /* Scale down checksum to accomodate it into 8 bits */
  for (b_i = 0; b_i < i1; b_i++) {
    for (b_j = 0; b_j < i1; b_j++) {
      i0 = (int)MATRIX_SIZE;
      for (k = 0; k < i0; k++) {
        p = ArScale->data[b_i + ArScale->size[0] * k] * BcScale->data[k +
          BcScale->size[0] * b_j];
        C->data[b_i + C->size[0] * b_j] += p;
        memset(&bin[0], 0, 19U * sizeof(double));
        j = 1;
        while ((j <= 19) && (p > 0.0)) {
          bin[j - 1] = rt_remd_snf(p, 2.0);
          p /= 2.0;
          p = floor(p);
          j++;
        }

        for (i = 0; i < 19; i++) {
          InjectErr = (c_rand() < dv0[i]);
          Bit = (bin[i] > 0.0);
          if (InjectErr) {
            Bit = !Bit;
          }

          bin[i] = Bit;
        }

        p = 1.0;
        d = 0.0;
        for (j = 0; j < 19; j++) {
          if (bin[j] != 0.0) {
            d += p * bin[j];
          }

          p *= 2.0;
        }

        Cerr->data[b_i + Cerr->size[0] * b_j] += d;
      }
    }
  }

  emxFree_real_T(&BcScale);
  emxFree_real_T(&ArScale);
}

/*
 * File trailer for Matrix_Mul_With_Errors.c
 *
 * [EOF]
 */
