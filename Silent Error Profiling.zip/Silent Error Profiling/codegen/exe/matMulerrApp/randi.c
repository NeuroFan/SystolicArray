/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: randi.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 30-Oct-2020 10:36:49
 */

/* Include Files */
#include <math.h>
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "randi.h"
#include "rand.h"

/* Function Definitions */

/*
 * Arguments    : double varargin_1
 *                double varargin_2
 *                emxArray_real_T *r
 * Return Type  : void
 */
void randi(double varargin_1, double varargin_2, emxArray_real_T *r)
{
  int i2;
  int k;
  b_rand(varargin_1, varargin_2, r);
  i2 = r->size[0] * r->size[1];
  for (k = 0; k < i2; k++) {
    r->data[k] = 1.0 + floor(r->data[k] * 4.0);
  }
}

/*
 * File trailer for randi.c
 *
 * [EOF]
 */
