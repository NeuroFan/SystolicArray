/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mat_ext.c
 *
 * Code generation for function 'mat_ext'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "mat_ext.h"
#include "matMulerrApp_emxutil.h"
#include "sum.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static emlrtRSInfo bb_emlrtRSI = { 7,  /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo cb_emlrtRSI = { 11, /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo db_emlrtRSI = { 14, /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo eb_emlrtRSI = { 16, /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo fb_emlrtRSI = { 17, /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo gb_emlrtRSI = { 18, /* lineNo */
  "mat_ext",                           /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pathName */
};

static emlrtRSInfo nb_emlrtRSI = { 26, /* lineNo */
  "cat",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/cat.m"/* pathName */
};

static emlrtRSInfo ob_emlrtRSI = { 101,/* lineNo */
  "cat_impl",                          /* fcnName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/cat.m"/* pathName */
};

static emlrtRTEInfo u_emlrtRTEI = { 5, /* lineNo */
  14,                                  /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo v_emlrtRTEI = { 7, /* lineNo */
  25,                                  /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo w_emlrtRTEI = { 11,/* lineNo */
  25,                                  /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo x_emlrtRTEI = { 16,/* lineNo */
  4,                                   /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo y_emlrtRTEI = { 17,/* lineNo */
  4,                                   /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo ab_emlrtRTEI = { 18,/* lineNo */
  27,                                  /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo bb_emlrtRTEI = { 18,/* lineNo */
  4,                                   /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo cb_emlrtRTEI = { 4,/* lineNo */
  4,                                   /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo db_emlrtRTEI = { 5,/* lineNo */
  4,                                   /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo eb_emlrtRTEI = { 14,/* lineNo */
  13,                                  /* colNo */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m"/* pName */
};

static emlrtRTEInfo vb_emlrtRTEI = { 282,/* lineNo */
  27,                                  /* colNo */
  "check_non_axis_size",               /* fName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/cat.m"/* pName */
};

static emlrtBCInfo m_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  11,                                  /* lineNo */
  29,                                  /* colNo */
  "A",                                 /* aName */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo n_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  7,                                   /* lineNo */
  27,                                  /* colNo */
  "A",                                 /* aName */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo o_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  7,                                   /* lineNo */
  8,                                   /* colNo */
  "sum_col",                           /* aName */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo p_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  11,                                  /* lineNo */
  8,                                   /* colNo */
  "sum_row",                           /* aName */
  "mat_ext",                           /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/mat_ext.m",/* pName */
  0                                    /* checkKind */
};

/* Function Definitions */
void mat_ext(const emlrtStack *sp, const emxArray_real_T *A, emxArray_real_T
             *A_col_ext, emxArray_real_T *A_row_ext, emxArray_real_T *A_both_ext)
{
  emxArray_real_T *sum_col;
  int32_T i10;
  int32_T i11;
  emxArray_real_T *sum_row;
  int32_T input_sizes_idx_0;
  int32_T loop_ub;
  int32_T b_input_sizes_idx_0;
  emxArray_real_T *b_A;
  emxArray_real_T *r4;
  real_T S;
  int32_T result;
  boolean_T empty_non_axis_sizes;
  int8_T sizes_idx_0;
  boolean_T b1;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &sum_col, 1, &cb_emlrtRTEI, true);
  i10 = A->size[0];
  i11 = sum_col->size[0];
  sum_col->size[0] = A->size[0];
  emxEnsureCapacity_real_T(sp, sum_col, i11, &u_emlrtRTEI);
  emxInit_real_T(sp, &sum_row, 2, &db_emlrtRTEI, true);
  for (input_sizes_idx_0 = 0; input_sizes_idx_0 < i10; input_sizes_idx_0++) {
    loop_ub = A->size[1];
    i11 = A->size[0];
    b_input_sizes_idx_0 = 1 + input_sizes_idx_0;
    if ((b_input_sizes_idx_0 < 1) || (b_input_sizes_idx_0 > i11)) {
      emlrtDynamicBoundsCheckR2012b(b_input_sizes_idx_0, 1, i11, &n_emlrtBCI, sp);
    }

    i11 = sum_row->size[0] * sum_row->size[1];
    sum_row->size[0] = 1;
    sum_row->size[1] = loop_ub;
    emxEnsureCapacity_real_T(sp, sum_row, i11, &v_emlrtRTEI);
    for (i11 = 0; i11 < loop_ub; i11++) {
      sum_row->data[i11] = A->data[(b_input_sizes_idx_0 + A->size[0] * i11) - 1];
    }

    i11 = sum_col->size[0];
    b_input_sizes_idx_0 = 1 + input_sizes_idx_0;
    if ((b_input_sizes_idx_0 < 1) || (b_input_sizes_idx_0 > i11)) {
      emlrtDynamicBoundsCheckR2012b(b_input_sizes_idx_0, 1, i11, &o_emlrtBCI, sp);
    }

    st.site = &bb_emlrtRSI;
    sum_col->data[b_input_sizes_idx_0 - 1] = sum(&st, sum_row);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  i10 = A->size[1];
  i11 = sum_row->size[0] * sum_row->size[1];
  sum_row->size[0] = 1;
  sum_row->size[1] = A->size[1];
  emxEnsureCapacity_real_T(sp, sum_row, i11, &u_emlrtRTEI);
  emxInit_real_T(sp, &b_A, 1, &w_emlrtRTEI, true);
  for (input_sizes_idx_0 = 0; input_sizes_idx_0 < i10; input_sizes_idx_0++) {
    loop_ub = A->size[0];
    i11 = A->size[1];
    b_input_sizes_idx_0 = 1 + input_sizes_idx_0;
    if ((b_input_sizes_idx_0 < 1) || (b_input_sizes_idx_0 > i11)) {
      emlrtDynamicBoundsCheckR2012b(b_input_sizes_idx_0, 1, i11, &m_emlrtBCI, sp);
    }

    i11 = b_A->size[0];
    b_A->size[0] = loop_ub;
    emxEnsureCapacity_real_T(sp, b_A, i11, &w_emlrtRTEI);
    for (i11 = 0; i11 < loop_ub; i11++) {
      b_A->data[i11] = A->data[i11 + A->size[0] * (b_input_sizes_idx_0 - 1)];
    }

    i11 = sum_row->size[1];
    b_input_sizes_idx_0 = 1 + input_sizes_idx_0;
    if ((b_input_sizes_idx_0 < 1) || (b_input_sizes_idx_0 > i11)) {
      emlrtDynamicBoundsCheckR2012b(b_input_sizes_idx_0, 1, i11, &p_emlrtBCI, sp);
    }

    st.site = &cb_emlrtRSI;
    sum_row->data[b_input_sizes_idx_0 - 1] = b_sum(&st, b_A);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxInit_real_T(sp, &r4, 2, &eb_emlrtRTEI, true);
  st.site = &db_emlrtRSI;
  c_sum(&st, A, r4);
  st.site = &db_emlrtRSI;
  S = sum(&st, r4);
  st.site = &eb_emlrtRSI;
  b_st.site = &nb_emlrtRSI;
  emxFree_real_T(&r4);
  if ((A->size[0] != 0) && (A->size[1] != 0)) {
    result = A->size[1];
  } else if (sum_row->size[1] != 0) {
    result = sum_row->size[1];
  } else {
    result = muIntScalarMax_sint32(A->size[1], 0);
  }

  c_st.site = &ob_emlrtRSI;
  if ((A->size[1] == result) || ((A->size[0] == 0) || (A->size[1] == 0))) {
  } else {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  if ((sum_row->size[1] == result) || (sum_row->size[1] == 0)) {
  } else {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  empty_non_axis_sizes = (result == 0);
  if (empty_non_axis_sizes || ((A->size[0] != 0) && (A->size[1] != 0))) {
    input_sizes_idx_0 = A->size[0];
  } else {
    input_sizes_idx_0 = 0;
  }

  if (empty_non_axis_sizes || (sum_row->size[1] != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }

  b_input_sizes_idx_0 = input_sizes_idx_0;
  input_sizes_idx_0 = sizes_idx_0;
  i10 = A_row_ext->size[0] * A_row_ext->size[1];
  A_row_ext->size[0] = b_input_sizes_idx_0 + sizes_idx_0;
  A_row_ext->size[1] = result;
  emxEnsureCapacity_real_T(&b_st, A_row_ext, i10, &x_emlrtRTEI);
  for (i10 = 0; i10 < result; i10++) {
    for (i11 = 0; i11 < b_input_sizes_idx_0; i11++) {
      A_row_ext->data[i11 + A_row_ext->size[0] * i10] = A->data[i11 +
        b_input_sizes_idx_0 * i10];
    }
  }

  for (i10 = 0; i10 < result; i10++) {
    for (i11 = 0; i11 < input_sizes_idx_0; i11++) {
      A_row_ext->data[b_input_sizes_idx_0 + A_row_ext->size[0] * i10] =
        sum_row->data[sizes_idx_0 * i10];
    }
  }

  emxFree_real_T(&sum_row);
  st.site = &fb_emlrtRSI;
  b_st.site = &nb_emlrtRSI;
  if ((A->size[0] != 0) && (A->size[1] != 0)) {
    result = A->size[0];
  } else if (sum_col->size[0] != 0) {
    result = sum_col->size[0];
  } else {
    result = muIntScalarMax_sint32(A->size[0], 0);
  }

  c_st.site = &ob_emlrtRSI;
  if ((A->size[0] == result) || ((A->size[0] == 0) || (A->size[1] == 0))) {
  } else {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  if ((sum_col->size[0] == result) || (sum_col->size[0] == 0)) {
  } else {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  empty_non_axis_sizes = (result == 0);
  if (empty_non_axis_sizes || ((A->size[0] != 0) && (A->size[1] != 0))) {
    input_sizes_idx_0 = A->size[1];
  } else {
    input_sizes_idx_0 = 0;
  }

  if (empty_non_axis_sizes || (sum_col->size[0] != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }

  i10 = A_col_ext->size[0] * A_col_ext->size[1];
  A_col_ext->size[0] = result;
  A_col_ext->size[1] = input_sizes_idx_0 + sizes_idx_0;
  emxEnsureCapacity_real_T(&b_st, A_col_ext, i10, &y_emlrtRTEI);
  for (i10 = 0; i10 < input_sizes_idx_0; i10++) {
    for (i11 = 0; i11 < result; i11++) {
      A_col_ext->data[i11 + A_col_ext->size[0] * i10] = A->data[i11 + result *
        i10];
    }
  }

  loop_ub = sizes_idx_0;
  for (i10 = 0; i10 < loop_ub; i10++) {
    for (i11 = 0; i11 < result; i11++) {
      A_col_ext->data[i11 + A_col_ext->size[0] * input_sizes_idx_0] =
        sum_col->data[i11];
    }
  }

  st.site = &gb_emlrtRSI;
  i10 = b_A->size[0];
  b_A->size[0] = sum_col->size[0] + 1;
  emxEnsureCapacity_real_T(&st, b_A, i10, &ab_emlrtRTEI);
  loop_ub = sum_col->size[0];
  for (i10 = 0; i10 < loop_ub; i10++) {
    b_A->data[i10] = sum_col->data[i10];
  }

  b_A->data[sum_col->size[0]] = S;
  b_st.site = &nb_emlrtRSI;
  emxFree_real_T(&sum_col);
  if ((A_row_ext->size[0] != 0) && (A_row_ext->size[1] != 0)) {
    result = A_row_ext->size[0];
  } else {
    result = b_A->size[0];
  }

  c_st.site = &ob_emlrtRSI;
  if ((A_row_ext->size[0] == result) || ((A_row_ext->size[0] == 0) ||
       (A_row_ext->size[1] == 0))) {
    b1 = true;
  } else {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  if (b_A->size[0] != result) {
    b1 = false;
  }

  if (!b1) {
    emlrtErrorWithMessageIdR2018a(&c_st, &vb_emlrtRTEI,
      "MATLAB:catenate:matrixDimensionMismatch",
      "MATLAB:catenate:matrixDimensionMismatch", 0);
  }

  if ((A_row_ext->size[0] != 0) && (A_row_ext->size[1] != 0)) {
    input_sizes_idx_0 = A_row_ext->size[1];
  } else {
    input_sizes_idx_0 = 0;
  }

  i10 = A_both_ext->size[0] * A_both_ext->size[1];
  A_both_ext->size[0] = result;
  A_both_ext->size[1] = input_sizes_idx_0 + 1;
  emxEnsureCapacity_real_T(&b_st, A_both_ext, i10, &bb_emlrtRTEI);
  for (i10 = 0; i10 < input_sizes_idx_0; i10++) {
    for (i11 = 0; i11 < result; i11++) {
      A_both_ext->data[i11 + A_both_ext->size[0] * i10] = A_row_ext->data[i11 +
        result * i10];
    }
  }

  for (i10 = 0; i10 < 1; i10++) {
    for (i11 = 0; i11 < result; i11++) {
      A_both_ext->data[i11 + A_both_ext->size[0] * input_sizes_idx_0] =
        b_A->data[i11];
    }
  }

  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (mat_ext.c) */
