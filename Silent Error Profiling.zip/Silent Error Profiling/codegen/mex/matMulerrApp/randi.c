/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * randi.c
 *
 * Code generation for function 'randi'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "randi.h"
#include "rand.h"

/* Variable Definitions */
static emlrtRSInfo t_emlrtRSI = { 60,  /* lineNo */
  "randi",                             /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/randi.m"/* pathName */
};

static emlrtRSInfo u_emlrtRSI = { 61,  /* lineNo */
  "randi",                             /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/randi.m"/* pathName */
};

static emlrtRTEInfo tb_emlrtRTEI = { 55,/* lineNo */
  23,                                  /* colNo */
  "assertValidSizeArg",                /* fName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/assertValidSizeArg.m"/* pName */
};

static emlrtRTEInfo ub_emlrtRTEI = { 61,/* lineNo */
  15,                                  /* colNo */
  "assertValidSizeArg",                /* fName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/assertValidSizeArg.m"/* pName */
};

/* Function Definitions */
void randi(const emlrtStack *sp, real_T varargin_1, real_T varargin_2,
           emxArray_real_T *r)
{
  boolean_T b0;
  real_T b_varargin_1;
  real_T b_varargin_2;
  int32_T i7;
  int32_T k;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &t_emlrtRSI;
  if ((varargin_1 != muDoubleScalarFloor(varargin_1)) || muDoubleScalarIsInf
      (varargin_1) || (varargin_1 < -2.147483648E+9) || (varargin_1 >
       2.147483647E+9)) {
    emlrtErrorWithMessageIdR2018a(&st, &tb_emlrtRTEI,
      "Coder:MATLAB:NonIntegerInput", "Coder:MATLAB:NonIntegerInput", 4, 12,
      MIN_int32_T, 12, MAX_int32_T);
  } else {
    b0 = true;
  }

  if ((varargin_2 != muDoubleScalarFloor(varargin_2)) || muDoubleScalarIsInf
      (varargin_2) || (varargin_2 < -2.147483648E+9) || (varargin_2 >
       2.147483647E+9)) {
    b0 = false;
  }

  if (!b0) {
    emlrtErrorWithMessageIdR2018a(&st, &tb_emlrtRTEI,
      "Coder:MATLAB:NonIntegerInput", "Coder:MATLAB:NonIntegerInput", 4, 12,
      MIN_int32_T, 12, MAX_int32_T);
  }

  if (varargin_1 <= 0.0) {
    b_varargin_1 = 0.0;
  } else {
    b_varargin_1 = varargin_1;
  }

  if (varargin_2 <= 0.0) {
    b_varargin_2 = 0.0;
  } else {
    b_varargin_2 = b_varargin_1 * varargin_2;
  }

  if (!(b_varargin_2 <= 2.147483647E+9)) {
    emlrtErrorWithMessageIdR2018a(&st, &ub_emlrtRTEI, "Coder:MATLAB:pmaxsize",
      "Coder:MATLAB:pmaxsize", 0);
  }

  st.site = &u_emlrtRSI;
  b_rand(&st, varargin_1, varargin_2, r);
  i7 = r->size[0] * r->size[1];
  for (k = 0; k < i7; k++) {
    r->data[k] = 1.0 + muDoubleScalarFloor(r->data[k] * 4.0);
  }
}

/* End of code generation (randi.c) */
