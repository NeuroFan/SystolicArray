/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * ABFTError.c
 *
 * Code generation for function 'ABFTError'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "ABFTError.h"
#include "eml_int_forloop_overflow_check.h"
#include "matMulerrApp_emxutil.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static emlrtRSInfo yb_emlrtRSI = { 4,  /* lineNo */
  "ABFTError",                         /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pathName */
};

static emlrtRSInfo ac_emlrtRSI = { 8,  /* lineNo */
  "ABFTError",                         /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pathName */
};

static emlrtRSInfo bc_emlrtRSI = { 177,/* lineNo */
  "colMajorFlatIter",                  /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/combineVectorElements.m"/* pathName */
};

static emlrtRSInfo cc_emlrtRSI = { 195,/* lineNo */
  "colMajorFlatIter",                  /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/combineVectorElements.m"/* pathName */
};

static emlrtRTEInfo hb_emlrtRTEI = { 4,/* lineNo */
  5,                                   /* colNo */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pName */
};

static emlrtRTEInfo ib_emlrtRTEI = { 6,/* lineNo */
  5,                                   /* colNo */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pName */
};

static emlrtRTEInfo jb_emlrtRTEI = { 7,/* lineNo */
  5,                                   /* colNo */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pName */
};

static emlrtECInfo d_emlrtECI = { -1,  /* nDims */
  6,                                   /* lineNo */
  18,                                  /* colNo */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m"/* pName */
};

static emlrtBCInfo q_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  4,                                   /* lineNo */
  40,                                  /* colNo */
  "Mat_Mul",                           /* aName */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo r_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  4,                                   /* lineNo */
  38,                                  /* colNo */
  "Mat_Mul",                           /* aName */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo s_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  4,                                   /* lineNo */
  34,                                  /* colNo */
  "Mat_Mul",                           /* aName */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo t_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  3,                                   /* lineNo */
  37,                                  /* colNo */
  "Mat_Mul",                           /* aName */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo u_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  3,                                   /* lineNo */
  33,                                  /* colNo */
  "Mat_Mul",                           /* aName */
  "ABFTError",                         /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/System_Simulations/ErrorCHK/ABFTError.m",/* pName */
  0                                    /* checkKind */
};

/* Function Definitions */
void ABFTError(const emlrtStack *sp, const emxArray_real_T *Mat_Mul, boolean_T
               *Error_ABFT, emxArray_boolean_T *ColumnsChecks)
{
  int32_T i12;
  int32_T loop_ub;
  int32_T vlen;
  int32_T b_loop_ub;
  emxArray_real_T *Computed_Sum;
  int32_T j;
  int32_T k;
  int32_T xoffset;
  emxArray_boolean_T *Comparison;
  real_T y;
  boolean_T overflow;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  if (1 > Mat_Mul->size[0]) {
    loop_ub = 0;
  } else {
    i12 = Mat_Mul->size[0];
    loop_ub = Mat_Mul->size[0];
    if ((loop_ub < 1) || (loop_ub > i12)) {
      emlrtDynamicBoundsCheckR2012b(loop_ub, 1, i12, &u_emlrtBCI, sp);
    }
  }

  i12 = Mat_Mul->size[1];
  vlen = Mat_Mul->size[1];
  if ((vlen < 1) || (vlen > i12)) {
    emlrtDynamicBoundsCheckR2012b(vlen, 1, i12, &t_emlrtBCI, sp);
  }

  if (1 > Mat_Mul->size[0]) {
    b_loop_ub = 0;
  } else {
    i12 = Mat_Mul->size[0];
    b_loop_ub = Mat_Mul->size[0];
    if ((b_loop_ub < 1) || (b_loop_ub > i12)) {
      emlrtDynamicBoundsCheckR2012b(b_loop_ub, 1, i12, &s_emlrtBCI, sp);
    }
  }

  if (1 > Mat_Mul->size[1] - 1) {
    vlen = 0;
  } else {
    i12 = Mat_Mul->size[1];
    if (1 > i12) {
      emlrtDynamicBoundsCheckR2012b(1, 1, i12, &r_emlrtBCI, sp);
    }

    i12 = Mat_Mul->size[1];
    vlen = Mat_Mul->size[1] - 1;
    if ((vlen < 1) || (vlen > i12)) {
      emlrtDynamicBoundsCheckR2012b(vlen, 1, i12, &q_emlrtBCI, sp);
    }
  }

  emxInit_real_T(sp, &Computed_Sum, 1, &hb_emlrtRTEI, true);
  st.site = &yb_emlrtRSI;
  b_st.site = &hb_emlrtRSI;
  c_st.site = &ib_emlrtRSI;
  if ((b_loop_ub == 0) || (vlen == 0)) {
    i12 = Computed_Sum->size[0];
    Computed_Sum->size[0] = b_loop_ub;
    emxEnsureCapacity_real_T(&c_st, Computed_Sum, i12, &fb_emlrtRTEI);
    for (i12 = 0; i12 < b_loop_ub; i12++) {
      Computed_Sum->data[i12] = 0.0;
    }
  } else {
    d_st.site = &jb_emlrtRSI;
    i12 = Computed_Sum->size[0];
    Computed_Sum->size[0] = b_loop_ub;
    emxEnsureCapacity_real_T(&d_st, Computed_Sum, i12, &gb_emlrtRTEI);
    e_st.site = &bc_emlrtRSI;
    if (b_loop_ub > 2147483646) {
      f_st.site = &lb_emlrtRSI;
      check_forloop_overflow_error(&f_st);
    }

    for (j = 0; j < b_loop_ub; j++) {
      Computed_Sum->data[j] = Mat_Mul->data[j % b_loop_ub + Mat_Mul->size[0] *
        (j / b_loop_ub)];
    }

    e_st.site = &kb_emlrtRSI;
    for (k = 2; k <= vlen; k++) {
      xoffset = (k - 1) * b_loop_ub;
      e_st.site = &cc_emlrtRSI;
      if ((1 <= b_loop_ub) && (b_loop_ub > 2147483646)) {
        f_st.site = &lb_emlrtRSI;
        check_forloop_overflow_error(&f_st);
      }

      for (j = 0; j < b_loop_ub; j++) {
        i12 = xoffset + j;
        Computed_Sum->data[j] += Mat_Mul->data[i12 % b_loop_ub + Mat_Mul->size[0]
          * (i12 / b_loop_ub)];
      }
    }
  }

  i12 = Computed_Sum->size[0];
  emxEnsureCapacity_real_T(sp, Computed_Sum, i12, &hb_emlrtRTEI);
  b_loop_ub = Computed_Sum->size[0];
  for (i12 = 0; i12 < b_loop_ub; i12++) {
    Computed_Sum->data[i12] /= 32.0;
  }

  emxInit_boolean_T(sp, &Comparison, 1, &ib_emlrtRTEI, true);
  i12 = Computed_Sum->size[0];
  if (loop_ub != i12) {
    emlrtSizeEqCheck1DR2012b(loop_ub, i12, &d_emlrtECI, sp);
  }

  vlen = Mat_Mul->size[1];
  i12 = Comparison->size[0];
  Comparison->size[0] = loop_ub;
  emxEnsureCapacity_boolean_T(sp, Comparison, i12, &ib_emlrtRTEI);
  for (i12 = 0; i12 < loop_ub; i12++) {
    Comparison->data[i12] = (Mat_Mul->data[i12 + Mat_Mul->size[0] * (vlen - 1)]
      != Computed_Sum->data[i12]);
  }

  emxFree_real_T(&Computed_Sum);
  i12 = ColumnsChecks->size[0] * ColumnsChecks->size[1];
  ColumnsChecks->size[0] = 1;
  ColumnsChecks->size[1] = Comparison->size[0];
  emxEnsureCapacity_boolean_T(sp, ColumnsChecks, i12, &jb_emlrtRTEI);
  loop_ub = Comparison->size[0];
  for (i12 = 0; i12 < loop_ub; i12++) {
    ColumnsChecks->data[i12] = Comparison->data[i12];
  }

  st.site = &ac_emlrtRSI;
  b_st.site = &hb_emlrtRSI;
  c_st.site = &ib_emlrtRSI;
  vlen = Comparison->size[0];
  if (Comparison->size[0] == 0) {
    y = 0.0;
  } else {
    d_st.site = &jb_emlrtRSI;
    y = Comparison->data[0];
    e_st.site = &kb_emlrtRSI;
    overflow = ((2 <= Comparison->size[0]) && (Comparison->size[0] > 2147483646));
    if (overflow) {
      f_st.site = &lb_emlrtRSI;
      check_forloop_overflow_error(&f_st);
    }

    for (k = 2; k <= vlen; k++) {
      y += (real_T)Comparison->data[k - 1];
    }
  }

  emxFree_boolean_T(&Comparison);
  *Error_ABFT = (y > 0.0);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (ABFTError.c) */
