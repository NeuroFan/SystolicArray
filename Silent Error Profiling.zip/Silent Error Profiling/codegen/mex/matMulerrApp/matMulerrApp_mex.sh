"/usr/local/matlab/toolbox/shared/coder/ninja/glnxa64/ninja" -v "$@"
