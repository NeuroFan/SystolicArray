/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp.h
 *
 * Code generation for function 'matMulerrApp'
 *
 */

#ifndef MATMULERRAPP_H
#define MATMULERRAPP_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern int32_T getThreadID(void);
extern void getThreadID_init(const emlrtStack *sp);
extern void matMulerrApp(const emlrtStack *sp, real_T N, real_T Mat_Size);

#endif

/* End of code generation (matMulerrApp.h) */
