/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Matrix_Mul_With_Errors.h
 *
 * Code generation for function 'Matrix_Mul_With_Errors'
 *
 */

#ifndef MATRIX_MUL_WITH_ERRORS_H
#define MATRIX_MUL_WITH_ERRORS_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void Matrix_Mul_With_Errors(const emlrtStack *sp, real_T MATRIX_SIZE,
  emxArray_real_T *C, emxArray_real_T *Cerr);

#endif

/* End of code generation (Matrix_Mul_With_Errors.h) */
