/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp_terminate.c
 *
 * Code generation for function 'matMulerrApp_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "matMulerrApp_terminate.h"
#include "eml_rand_shr3cong_stateful.h"
#include "eml_rand_mcg16807_stateful.h"
#include "timeKeeper.h"
#include "eml_rand.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "_coder_matMulerrApp_mex.h"
#include "matMulerrApp_data.h"

/* Function Definitions */
void matMulerrApp_atexit(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  c_eml_rand_mt19937ar_stateful_f(&st);
  eml_rand_shr3cong_stateful_free();
  eml_rand_mcg16807_stateful_free();
  eml_rand_free(&st);
  timeKeeper_free();
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

void matMulerrApp_terminate(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (matMulerrApp_terminate.c) */
