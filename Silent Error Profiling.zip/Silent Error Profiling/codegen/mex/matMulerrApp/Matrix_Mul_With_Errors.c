/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Matrix_Mul_With_Errors.c
 *
 * Code generation for function 'Matrix_Mul_With_Errors'
 *
 */

/* Include files */
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "Matrix_Mul_With_Errors.h"
#include "matMulerrApp_emxutil.h"
#include "rand.h"
#include "mat_ext.h"
#include "randi.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static emlrtRSInfo o_emlrtRSI = { 7,   /* lineNo */
  "Matrix_Mul_With_Errors",            /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pathName */
};

static emlrtRSInfo p_emlrtRSI = { 8,   /* lineNo */
  "Matrix_Mul_With_Errors",            /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pathName */
};

static emlrtRSInfo q_emlrtRSI = { 13,  /* lineNo */
  "Matrix_Mul_With_Errors",            /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pathName */
};

static emlrtRSInfo r_emlrtRSI = { 14,  /* lineNo */
  "Matrix_Mul_With_Errors",            /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pathName */
};

static emlrtRSInfo s_emlrtRSI = { 27,  /* lineNo */
  "Matrix_Mul_With_Errors",            /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pathName */
};

static emlrtRSInfo pb_emlrtRSI = { 3,  /* lineNo */
  "inject_error",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/inject_error.m"/* pathName */
};

static emlrtRSInfo qb_emlrtRSI = { 5,  /* lineNo */
  "inject_error",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/inject_error.m"/* pathName */
};

static emlrtRSInfo rb_emlrtRSI = { 12, /* lineNo */
  "inject_error",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/inject_error.m"/* pathName */
};

static emlrtRSInfo sb_emlrtRSI = { 22, /* lineNo */
  "de2bi",                             /* fcnName */
  "/usr/local/matlab/toolbox/comm/comm/eml/de2bi.m"/* pathName */
};

static emlrtRSInfo xb_emlrtRSI = { 53, /* lineNo */
  "bi2de",                             /* fcnName */
  "/usr/local/matlab/toolbox/comm/comm/eml/bi2de.m"/* pathName */
};

static emlrtRTEInfo j_emlrtRTEI = { 9, /* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo k_emlrtRTEI = { 10,/* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo l_emlrtRTEI = { 52,/* lineNo */
  9,                                   /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo m_emlrtRTEI = { 16,/* lineNo */
  22,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo n_emlrtRTEI = { 17,/* lineNo */
  22,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo o_emlrtRTEI = { 15,/* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo p_emlrtRTEI = { 15,/* lineNo */
  16,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo q_emlrtRTEI = { 1, /* lineNo */
  22,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo r_emlrtRTEI = { 8, /* lineNo */
  16,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtBCInfo c_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  16,                                  /* lineNo */
  25,                                  /* colNo */
  "Ar",                                /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo d_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  27,                                  /* colNo */
  "Bc",                                /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRTEInfo mb_emlrtRTEI = { 21,/* lineNo */
  13,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo nb_emlrtRTEI = { 22,/* lineNo */
  17,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo ob_emlrtRTEI = { 23,/* lineNo */
  21,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtBCInfo e_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  16,                                  /* lineNo */
  13,                                  /* colNo */
  "ArScale",                           /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo b_emlrtECI = { -1,  /* nDims */
  16,                                  /* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtBCInfo f_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  15,                                  /* colNo */
  "BcScale",                           /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c_emlrtECI = { -1,  /* nDims */
  17,                                  /* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m"/* pName */
};

static emlrtRTEInfo pb_emlrtRTEI = { 116,/* lineNo */
  23,                                  /* colNo */
  "GET_N",                             /* fName */
  "/usr/local/matlab/toolbox/comm/comm/eml/de2bi.m"/* pName */
};

static emlrtRTEInfo qb_emlrtRTEI = { 136,/* lineNo */
  1,                                   /* colNo */
  "GET_N",                             /* fName */
  "/usr/local/matlab/toolbox/comm/comm/eml/de2bi.m"/* pName */
};

static emlrtRTEInfo rb_emlrtRTEI = { 148,/* lineNo */
  23,                                  /* colNo */
  "UPDATE_DECIMAL",                    /* fName */
  "/usr/local/matlab/toolbox/comm/comm/eml/bi2de.m"/* pName */
};

static emlrtRTEInfo sb_emlrtRTEI = { 147,/* lineNo */
  1,                                   /* colNo */
  "UPDATE_DECIMAL",                    /* fName */
  "/usr/local/matlab/toolbox/comm/comm/eml/bi2de.m"/* pName */
};

static emlrtDCInfo d_emlrtDCI = { 9,   /* lineNo */
  15,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo e_emlrtDCI = { 9,   /* lineNo */
  15,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  4                                    /* checkKind */
};

static emlrtDCInfo f_emlrtDCI = { 9,   /* lineNo */
  19,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo g_emlrtDCI = { 9,   /* lineNo */
  19,                                  /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  4                                    /* checkKind */
};

static emlrtDCInfo h_emlrtDCI = { 9,   /* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo i_emlrtDCI = { 9,   /* lineNo */
  5,                                   /* colNo */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  4                                    /* checkKind */
};

static emlrtBCInfo g_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  21,                                  /* colNo */
  "ArScale",                           /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo h_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  34,                                  /* colNo */
  "BcScale",                           /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo i_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  26,                                  /* lineNo */
  26,                                  /* colNo */
  "C",                                 /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo j_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  26,                                  /* lineNo */
  17,                                  /* colNo */
  "C",                                 /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo k_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  28,                                  /* lineNo */
  29,                                  /* colNo */
  "Cerr",                              /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo l_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  28,                                  /* lineNo */
  17,                                  /* colNo */
  "Cerr",                              /* aName */
  "Matrix_Mul_With_Errors",            /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/Matrix_Mul_With_Errors.m",/* pName */
  0                                    /* checkKind */
};

/* Function Definitions */
void Matrix_Mul_With_Errors(const emlrtStack *sp, real_T MATRIX_SIZE,
  emxArray_real_T *C, emxArray_real_T *Cerr)
{
  emxArray_real_T *BcScale;
  emxArray_real_T *b;
  int32_T i3;
  int32_T loop_ub;
  int32_T i4;
  emxArray_real_T *r1;
  emxArray_real_T *ArScale;
  emxArray_real_T *Af;
  emxArray_real_T *r2;
  int32_T j;
  int32_T iv3[2];
  emxArray_real_T *r3;
  int32_T i;
  int32_T b_j;
  int32_T k;
  int32_T i5;
  int32_T i6;
  real_T p;
  real_T nmin;
  real_T bin[19];
  boolean_T InjectErr;
  static const real_T dv0[19] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5 };

  boolean_T Bit;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &BcScale, 2, &p_emlrtRTEI, true);
  emxInit_real_T(sp, &b, 2, &r_emlrtRTEI, true);

  /* matrix size N*N */
  st.site = &o_emlrtRSI;
  randi(&st, MATRIX_SIZE, MATRIX_SIZE, BcScale);
  st.site = &p_emlrtRSI;
  randi(&st, MATRIX_SIZE, MATRIX_SIZE, b);
  i3 = C->size[0] * C->size[1];
  if (!(MATRIX_SIZE + 1.0 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(MATRIX_SIZE + 1.0, &e_emlrtDCI, sp);
  }

  if (MATRIX_SIZE + 1.0 != (int32_T)muDoubleScalarFloor(MATRIX_SIZE + 1.0)) {
    emlrtIntegerCheckR2012b(MATRIX_SIZE + 1.0, &d_emlrtDCI, sp);
  }

  C->size[0] = (int32_T)(MATRIX_SIZE + 1.0);
  if (!(MATRIX_SIZE + 1.0 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(MATRIX_SIZE + 1.0, &g_emlrtDCI, sp);
  }

  if (MATRIX_SIZE + 1.0 != (int32_T)muDoubleScalarFloor(MATRIX_SIZE + 1.0)) {
    emlrtIntegerCheckR2012b(MATRIX_SIZE + 1.0, &f_emlrtDCI, sp);
  }

  C->size[1] = (int32_T)(MATRIX_SIZE + 1.0);
  emxEnsureCapacity_real_T(sp, C, i3, &j_emlrtRTEI);
  if (!(MATRIX_SIZE + 1.0 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(MATRIX_SIZE + 1.0, &i_emlrtDCI, sp);
  }

  if (MATRIX_SIZE + 1.0 != (int32_T)muDoubleScalarFloor(MATRIX_SIZE + 1.0)) {
    emlrtIntegerCheckR2012b(MATRIX_SIZE + 1.0, &h_emlrtDCI, sp);
  }

  if (!(MATRIX_SIZE + 1.0 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(MATRIX_SIZE + 1.0, &i_emlrtDCI, sp);
  }

  if (MATRIX_SIZE + 1.0 != (int32_T)muDoubleScalarFloor(MATRIX_SIZE + 1.0)) {
    emlrtIntegerCheckR2012b(MATRIX_SIZE + 1.0, &h_emlrtDCI, sp);
  }

  loop_ub = (int32_T)(MATRIX_SIZE + 1.0) * (int32_T)(MATRIX_SIZE + 1.0);
  for (i3 = 0; i3 < loop_ub; i3++) {
    C->data[i3] = 0.0;
  }

  i3 = Cerr->size[0] * Cerr->size[1];
  i4 = (int32_T)(MATRIX_SIZE + 1.0);
  Cerr->size[0] = i4;
  Cerr->size[1] = i4;
  emxEnsureCapacity_real_T(sp, Cerr, i3, &k_emlrtRTEI);
  loop_ub = i4 * i4;
  for (i3 = 0; i3 < loop_ub; i3++) {
    Cerr->data[i3] = 0.0;
  }

  emxInit_real_T(sp, &r1, 2, &l_emlrtRTEI, true);
  i3 = r1->size[0] * r1->size[1];
  r1->size[0] = BcScale->size[0];
  r1->size[1] = BcScale->size[1];
  emxEnsureCapacity_real_T(sp, r1, i3, &l_emlrtRTEI);
  loop_ub = BcScale->size[0] * BcScale->size[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r1->data[i3] = 32.0 * BcScale->data[i3];
  }

  emxInit_real_T(sp, &ArScale, 2, &o_emlrtRTEI, true);
  emxInit_real_T(sp, &Af, 2, &q_emlrtRTEI, true);
  st.site = &q_emlrtRSI;
  mat_ext(&st, r1, BcScale, ArScale, Af);
  i3 = r1->size[0] * r1->size[1];
  r1->size[0] = b->size[0];
  r1->size[1] = b->size[1];
  emxEnsureCapacity_real_T(sp, r1, i3, &l_emlrtRTEI);
  loop_ub = b->size[0] * b->size[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r1->data[i3] = 32.0 * b->data[i3];
  }

  emxInit_real_T(sp, &r2, 2, &q_emlrtRTEI, true);
  st.site = &r_emlrtRSI;
  mat_ext(&st, r1, BcScale, Af, b);
  i3 = ArScale->size[0];
  j = ArScale->size[0];
  if ((j < 1) || (j > i3)) {
    emlrtDynamicBoundsCheckR2012b(j, 1, i3, &e_emlrtBCI, sp);
  }

  loop_ub = ArScale->size[1];
  i3 = ArScale->size[0];
  j = ArScale->size[0];
  if ((j < 1) || (j > i3)) {
    emlrtDynamicBoundsCheckR2012b(j, 1, i3, &c_emlrtBCI, sp);
  }

  i3 = r2->size[0] * r2->size[1];
  r2->size[0] = 1;
  r2->size[1] = loop_ub;
  emxEnsureCapacity_real_T(sp, r2, i3, &m_emlrtRTEI);
  emxFree_real_T(&r1);
  emxFree_real_T(&b);
  emxFree_real_T(&Af);
  for (i3 = 0; i3 < loop_ub; i3++) {
    r2->data[i3] = ArScale->data[(j + ArScale->size[0] * i3) - 1] / 32.0;
  }

  i3 = ArScale->size[1];
  iv3[0] = 1;
  iv3[1] = i3;
  emlrtSubAssignSizeCheckR2012b(&iv3[0], 2, &(*(int32_T (*)[2])r2->size)[0], 2,
    &b_emlrtECI, sp);
  i3 = ArScale->size[0] - 1;
  loop_ub = r2->size[1];
  for (j = 0; j < loop_ub; j++) {
    ArScale->data[i3 + ArScale->size[0] * j] = r2->data[j];
  }

  emxFree_real_T(&r2);
  emxInit_real_T(sp, &r3, 1, &q_emlrtRTEI, true);

  /* Scale down checksum to accomodate it into 8 bits */
  i3 = BcScale->size[1];
  j = BcScale->size[1];
  if ((j < 1) || (j > i3)) {
    emlrtDynamicBoundsCheckR2012b(j, 1, i3, &f_emlrtBCI, sp);
  }

  loop_ub = BcScale->size[0];
  i3 = BcScale->size[1];
  j = BcScale->size[1];
  if ((j < 1) || (j > i3)) {
    emlrtDynamicBoundsCheckR2012b(j, 1, i3, &d_emlrtBCI, sp);
  }

  i3 = r3->size[0];
  r3->size[0] = loop_ub;
  emxEnsureCapacity_real_T(sp, r3, i3, &n_emlrtRTEI);
  for (i3 = 0; i3 < loop_ub; i3++) {
    r3->data[i3] = BcScale->data[i3 + BcScale->size[0] * (j - 1)] / 32.0;
  }

  i3 = BcScale->size[0];
  emlrtSubAssignSizeCheckR2012b(&i3, 1, &(*(int32_T (*)[1])r3->size)[0], 1,
    &c_emlrtECI, sp);
  i3 = BcScale->size[1] - 1;
  loop_ub = r3->size[0];
  for (j = 0; j < loop_ub; j++) {
    BcScale->data[j + BcScale->size[0] * i3] = r3->data[j];
  }

  emxFree_real_T(&r3);

  /* Scale down checksum to accomodate it into 8 bits */
  emlrtForLoopVectorCheckR2012b(1.0, 1.0, MATRIX_SIZE + 1.0, mxDOUBLE_CLASS,
    (int32_T)(MATRIX_SIZE + 1.0), &mb_emlrtRTEI, sp);
  for (i = 0; i < i4; i++) {
    emlrtForLoopVectorCheckR2012b(1.0, 1.0, MATRIX_SIZE + 1.0, mxDOUBLE_CLASS,
      (int32_T)(MATRIX_SIZE + 1.0), &nb_emlrtRTEI, sp);
    for (b_j = 0; b_j < i4; b_j++) {
      i3 = (int32_T)MATRIX_SIZE;
      emlrtForLoopVectorCheckR2012b(1.0, 1.0, MATRIX_SIZE, mxDOUBLE_CLASS,
        (int32_T)MATRIX_SIZE, &ob_emlrtRTEI, sp);
      for (k = 0; k < i3; k++) {
        j = ArScale->size[0];
        i5 = (int32_T)(1U + i);
        if ((i5 < 1) || (i5 > j)) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, j, &g_emlrtBCI, sp);
        }

        j = ArScale->size[1];
        loop_ub = (int32_T)(1U + k);
        if ((loop_ub < 1) || (loop_ub > j)) {
          emlrtDynamicBoundsCheckR2012b(loop_ub, 1, j, &g_emlrtBCI, sp);
        }

        j = BcScale->size[0];
        if ((loop_ub < 1) || (loop_ub > j)) {
          emlrtDynamicBoundsCheckR2012b(loop_ub, 1, j, &h_emlrtBCI, sp);
        }

        j = BcScale->size[1];
        i6 = (int32_T)(1U + b_j);
        if ((i6 < 1) || (i6 > j)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, j, &h_emlrtBCI, sp);
        }

        p = ArScale->data[(i5 + ArScale->size[0] * (loop_ub - 1)) - 1] *
          BcScale->data[(loop_ub + BcScale->size[0] * (i6 - 1)) - 1];
        j = C->size[0];
        if ((i5 < 1) || (i5 > j)) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, j, &i_emlrtBCI, sp);
        }

        j = C->size[1];
        if ((i6 < 1) || (i6 > j)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, j, &i_emlrtBCI, sp);
        }

        j = C->size[0];
        if ((i5 < 1) || (i5 > j)) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, j, &j_emlrtBCI, sp);
        }

        j = C->size[1];
        if ((i6 < 1) || (i6 > j)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, j, &j_emlrtBCI, sp);
        }

        C->data[(i5 + C->size[0] * (i6 - 1)) - 1] += p;
        st.site = &s_emlrtRSI;
        b_st.site = &pb_emlrtRSI;
        c_st.site = &sb_emlrtRSI;
        if (muDoubleScalarIsInf(p) || muDoubleScalarIsNaN(p) ||
            ((!(muDoubleScalarFloor(p) == p)) || (p < 0.0))) {
          emlrtErrorWithMessageIdR2018a(&c_st, &pb_emlrtRTEI,
            "comm:de2bi:InvalidInput", "comm:de2bi:InvalidInput", 0);
        }

        if (p != 0.0) {
          nmin = muDoubleScalarFloor(muDoubleScalarLog(p) / 0.69314718055994529)
            + 1.0;
        } else {
          nmin = 1.0;
        }

        if (!(muDoubleScalarPower(2.0, nmin) > p)) {
          nmin++;
        }

        if (19.0 < nmin) {
          emlrtErrorWithMessageIdR2018a(&c_st, &qb_emlrtRTEI,
            "comm:de2bi:SmallN", "comm:de2bi:SmallN", 0);
        }

        memset(&bin[0], 0, 19U * sizeof(real_T));
        j = 1;
        while ((j <= 19) && (p > 0.0)) {
          bin[j - 1] = muDoubleScalarRem(p, 2.0);
          p /= 2.0;
          p = muDoubleScalarFloor(p);
          j++;
        }

        for (loop_ub = 0; loop_ub < 19; loop_ub++) {
          b_st.site = &qb_emlrtRSI;
          InjectErr = (c_rand(&b_st) < dv0[loop_ub]);
          Bit = (bin[loop_ub] > 0.0);
          if (InjectErr) {
            Bit = !Bit;
          }

          bin[loop_ub] = Bit;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(&st);
          }
        }

        b_st.site = &rb_emlrtRSI;
        p = 1.0;
        nmin = 0.0;
        for (j = 0; j < 19; j++) {
          c_st.site = &xb_emlrtRSI;
          if (bin[j] >= 2.0) {
            emlrtErrorWithMessageIdR2018a(&c_st, &sb_emlrtRTEI,
              "comm:bi2de:InvalidInputElement", "comm:bi2de:InvalidInputElement",
              0);
          }

          if (!(muDoubleScalarFloor(bin[j]) == bin[j])) {
            emlrtErrorWithMessageIdR2018a(&c_st, &rb_emlrtRTEI,
              "comm:bi2de:InvalidInput2", "comm:bi2de:InvalidInput2", 0);
          }

          if (bin[j] != 0.0) {
            nmin += p * bin[j];
          }

          p *= 2.0;
        }

        j = Cerr->size[0];
        if ((i5 < 1) || (i5 > j)) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, j, &k_emlrtBCI, sp);
        }

        j = Cerr->size[1];
        if ((i6 < 1) || (i6 > j)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, j, &k_emlrtBCI, sp);
        }

        j = Cerr->size[0];
        if ((i5 < 1) || (i5 > j)) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, j, &l_emlrtBCI, sp);
        }

        j = Cerr->size[1];
        if ((i6 < 1) || (i6 > j)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, j, &l_emlrtBCI, sp);
        }

        Cerr->data[(i5 + Cerr->size[0] * (i6 - 1)) - 1] += nmin;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxFree_real_T(&BcScale);
  emxFree_real_T(&ArScale);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (Matrix_Mul_With_Errors.c) */
