/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp_initialize.c
 *
 * Code generation for function 'matMulerrApp_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "matMulerrApp_initialize.h"
#include "eml_rand_shr3cong_stateful.h"
#include "eml_rand_mcg16807_stateful.h"
#include "timeKeeper.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "eml_rand.h"
#include "_coder_matMulerrApp_mex.h"
#include "matMulerrApp_data.h"

/* Function Declarations */
static void matMulerrApp_once(const emlrtStack *sp);

/* Function Definitions */
static void matMulerrApp_once(const emlrtStack *sp)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  eml_rand_shr3cong_stateful_free();
  eml_rand_mcg16807_stateful_free();
  timeKeeper_free();
  st.site = NULL;
  getThreadID_init(&st);
  st.site = NULL;
  eml_rand_init(&st);
  eml_rand_mcg16807_stateful_init();
  eml_rand_shr3cong_stateful_init();
  st.site = NULL;
  c_eml_rand_mt19937ar_stateful_i(&st);
}

void matMulerrApp_initialize(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtLicenseCheckR2012b(&st, "Communication_Toolbox", 2);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    matMulerrApp_once(&st);
  }
}

/* End of code generation (matMulerrApp_initialize.c) */
