/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp_terminate.h
 *
 * Code generation for function 'matMulerrApp_terminate'
 *
 */

#ifndef MATMULERRAPP_TERMINATE_H
#define MATMULERRAPP_TERMINATE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void matMulerrApp_atexit(void);
extern void matMulerrApp_terminate(void);

#endif

/* End of code generation (matMulerrApp_terminate.h) */
