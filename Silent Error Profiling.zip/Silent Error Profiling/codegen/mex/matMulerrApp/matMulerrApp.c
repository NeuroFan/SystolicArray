/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp.c
 *
 * Code generation for function 'matMulerrApp'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "eml_rand.h"
#include "matMulerrApp_emxutil.h"
#include "sum.h"
#include "eml_int_forloop_overflow_check.h"
#include "ABFTError.h"
#include "Matrix_Mul_With_Errors.h"
#include "toc.h"
#include "tic.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static int32_T threadID;

#pragma omp threadprivate (threadID)

static emlrtRTEInfo emlrtRTEI = { 2,   /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo b_emlrtRTEI = { 18,/* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRSInfo emlrtRSI = { 2,     /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 10,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo c_emlrtRSI = { 11,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo d_emlrtRSI = { 12,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 18,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo f_emlrtRSI = { 20,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo g_emlrtRSI = { 22,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 24,  /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo i_emlrtRSI = { 8,   /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo dc_emlrtRSI = { 16, /* lineNo */
  "abs",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/elfun/abs.m"/* pathName */
};

static emlrtRSInfo ec_emlrtRSI = { 74, /* lineNo */
  "applyScalarFunction",               /* fcnName */
  "/usr/local/matlab/toolbox/eml/eml/+coder/+internal/applyScalarFunction.m"/* pathName */
};

static emlrtMCInfo emlrtMCI = { 19,    /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtMCInfo b_emlrtMCI = { 20,  /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtMCInfo c_emlrtMCI = { 21,  /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtMCInfo d_emlrtMCI = { 22,  /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtMCInfo e_emlrtMCI = { 23,  /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtMCInfo f_emlrtMCI = { 24,  /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo c_emlrtRTEI = { 3, /* lineNo */
  17,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo d_emlrtRTEI = { 12,/* lineNo */
  31,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo e_emlrtRTEI = { 16,/* lineNo */
  5,                                   /* colNo */
  "abs",                               /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/elfun/abs.m"/* pName */
};

static emlrtRTEInfo f_emlrtRTEI = { 1, /* lineNo */
  10,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo g_emlrtRTEI = { 12,/* lineNo */
  27,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo h_emlrtRTEI = { 3, /* lineNo */
  6,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtRTEInfo i_emlrtRTEI = { 4, /* lineNo */
  5,                                   /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtDCInfo emlrtDCI = { 3,     /* lineNo */
  23,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m",/* pName */
  4                                    /* checkKind */
};

static emlrtDCInfo b_emlrtDCI = { 3,   /* lineNo */
  23,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo c_emlrtDCI = { 8,   /* lineNo */
  18,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m",/* pName */
  1                                    /* checkKind */
};

static emlrtRTEInfo kb_emlrtRTEI = { 8,/* lineNo */
  16,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtECInfo emlrtECI = { -1,    /* nDims */
  12,                                  /* lineNo */
  31,                                  /* colNo */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { -1,    /* iFirst */
  -1,                                  /* iLast */
  11,                                  /* lineNo */
  10,                                  /* colNo */
  "arr_ABFT",                          /* aName */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo b_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  12,                                  /* lineNo */
  9,                                   /* colNo */
  "arr_Real",                          /* aName */
  "matMulerrApp",                      /* fName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRSInfo kc_emlrtRSI = { 23, /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo lc_emlrtRSI = { 21, /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

static emlrtRSInfo mc_emlrtRSI = { 19, /* lineNo */
  "matMulerrApp",                      /* fcnName */
  "/kotidir04/msafarpo/Desktop/Silent Error Profiling/matMulerrApp.m"/* pathName */
};

/* Function Declarations */
static void disp(const emlrtStack *sp, const mxArray *b, emlrtMCInfo *location);

/* Function Definitions */
static void disp(const emlrtStack *sp, const mxArray *b, emlrtMCInfo *location)
{
  const mxArray *pArray;
  pArray = b;
  emlrtCallMATLABR2012b(sp, 0, NULL, 1, &pArray, "disp", true, location);
}

int32_T getThreadID(void)
{
  return threadID;
}

void getThreadID_init(const emlrtStack *sp)
{
  int32_T ub_loop;
  int32_T i;
  jmp_buf * volatile emlrtJBStack;
  ub_loop = omp_get_max_threads();
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);

#pragma omp parallel for schedule(static)\
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs()))

  for (i = 1; i <= ub_loop; i++) {
    threadID = omp_get_thread_num();
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
}

void matMulerrApp(const emlrtStack *sp, real_T N, real_T Mat_Size)
{
  emxArray_real_T *arr_ABFT;
  emxArray_real_T *arr_Real;
  real_T u_tv_sec;
  real_T u_tv_nsec;
  const mxArray *y;
  static const char * sv0[2] = { "tv_sec", "tv_nsec" };

  const mxArray *b_y;
  const mxArray *m0;
  const mxArray *m1;
  int32_T ub_loop;
  int32_T i0;
  int32_T i;
  emxArray_real_T *r0;
  emxArray_real_T *x;
  emxArray_real_T *C;
  emxArray_real_T *Cerr;
  const mxArray *m2;
  emxArray_boolean_T *unusedU0;
  const mxArray *m3;
  static const int32_T iv0[2] = { 1, 37 };

  static const char_T u[37] = { 'T', 'o', 't', 'a', 'l', ' ', 'n', 'u', 'm', 'b',
    'e', 'r', ' ', 'o', 'f', ' ', 'A', 'B', 'F', 'T', ' ', 'd', 'e', 't', 'e',
    'c', 't', 'e', 'd', ' ', 'E', 'r', 'r', 'o', 'r', 's', ' ' };

  boolean_T overflow;
  const mxArray *m4;
  const mxArray *m5;
  static const int32_T iv1[2] = { 1, 33 };

  static const char_T b_u[33] = { 'T', 'o', 't', 'a', 'l', ' ', 'n', 'u', 'm',
    'b', 'e', 'r', ' ', 'o', 'f', ' ', 'e', 'x', 'i', 's', 't', 'i', 'n', 'g',
    ' ', ' ', 'E', 'r', 'r', 'o', 'r', 's', ' ' };

  int32_T i1;
  int32_T i2;
  const mxArray *m6;
  int32_T loop_ub;
  const mxArray *m7;
  static const int32_T iv2[2] = { 1, 30 };

  static const char_T c_u[30] = { 'T', 'o', 't', 'a', 'l', ' ', 'n', 'u', 'm',
    'b', 'e', 'r', ' ', 'o', 'f', ' ', 's', 'i', 'l', 'e', 'n', 't', ' ', 'E',
    'r', 'r', 'o', 'r', 's', ' ' };

  const mxArray *m8;
  int32_T nx;
  uint32_T x_idx_0;
  jmp_buf * volatile emlrtJBStack;
  emlrtStack st;
  emlrtStack b_st;
  jmp_buf b_emlrtJBEnviron;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  boolean_T emlrtHadParallelError = false;
  st.prev = sp;
  st.tls = sp->tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &arr_ABFT, 1, &h_emlrtRTEI, true);
  emxInit_real_T(sp, &arr_Real, 1, &i_emlrtRTEI, true);
  emlrtAssertMATLABThread(sp, &emlrtRTEI);
  emlrtAssertMATLABThread(sp, &emlrtRTEI);
  st.site = &emlrtRSI;
  tic(&st, &u_tv_sec, &u_tv_nsec);
  y = NULL;
  emlrtAssign(&y, emlrtCreateStructMatrix(1, 1, 2, sv0));
  b_y = NULL;
  m0 = emlrtCreateDoubleScalar(u_tv_sec);
  emlrtAssign(&b_y, m0);
  emlrtSetFieldR2017b(y, 0, "tv_sec", b_y, 0);
  b_y = NULL;
  m1 = emlrtCreateDoubleScalar(u_tv_nsec);
  emlrtAssign(&b_y, m1);
  emlrtSetFieldR2017b(y, 0, "tv_nsec", b_y, 1);
  emlrtDisplayR2012b(y, "ans", &emlrtRTEI, sp);
  if (!(N >= 0.0)) {
    emlrtNonNegativeCheckR2012b(N, &emlrtDCI, sp);
  }

  u_tv_sec = (int32_T)muDoubleScalarFloor(N);
  if (N != u_tv_sec) {
    emlrtIntegerCheckR2012b(N, &b_emlrtDCI, sp);
  }

  /* ColCHK = zeros(Mat_Size,N); */
  if (N != u_tv_sec) {
    emlrtIntegerCheckR2012b(N, &c_emlrtDCI, sp);
  }

  emlrtForLoopVectorCheckR2012b(1.0, 1.0, N, mxDOUBLE_CLASS, (int32_T)N,
    &kb_emlrtRTEI, sp);
  ub_loop = arr_ABFT->size[0];
  i0 = (int32_T)N;
  arr_ABFT->size[0] = i0;
  emxEnsureCapacity_real_T(sp, arr_ABFT, ub_loop, &c_emlrtRTEI);
  ub_loop = arr_Real->size[0];
  arr_Real->size[0] = i0;
  emxEnsureCapacity_real_T(sp, arr_Real, ub_loop, &c_emlrtRTEI);
  ub_loop = i0 - 1;
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);
  if (!omp_in_parallel()) {
    c_st.site = &i_emlrtRSI;
    c_eml_rand_mt19937ar_stateful_s(true);
    c_st.site = &i_emlrtRSI;
    eml_rand_swap();
  }

#pragma omp parallel \
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs())) \
 private(r0,x,C,Cerr,unusedU0,overflow,b_emlrtJBEnviron,f_st,i1,i2,loop_ub,nx,x_idx_0) \
 firstprivate(b_st,c_st,d_st,e_st,emlrtHadParallelError)

  {
    if (setjmp(b_emlrtJBEnviron) == 0) {
      b_st.prev = sp;
      b_st.tls = emlrtAllocTLS(sp, omp_get_thread_num());
      b_st.site = NULL;
      emlrtSetJmpBuf(&b_st, &b_emlrtJBEnviron);
      c_st.prev = &b_st;
      c_st.tls = b_st.tls;
      d_st.prev = &c_st;
      d_st.tls = c_st.tls;
      e_st.prev = &d_st;
      e_st.tls = d_st.tls;
      f_st.prev = &e_st;
      f_st.tls = e_st.tls;
      emxInit_real_T(&b_st, &r0, 1, &g_emlrtRTEI, true);
      emxInit_real_T(&b_st, &x, 1, &d_emlrtRTEI, true);
      emxInit_real_T(&b_st, &C, 2, &f_emlrtRTEI, true);
      emxInit_real_T(&b_st, &Cerr, 2, &f_emlrtRTEI, true);
      emxInit_boolean_T(&b_st, &unusedU0, 2, &f_emlrtRTEI, true);
    } else {
      emlrtHadParallelError = true;
    }

#pragma omp for nowait

    for (i = 0; i <= ub_loop; i++) {
      if (emlrtHadParallelError)
        continue;
      if (setjmp(b_emlrtJBEnviron) == 0) {
        /* possible race condition, check later */
        /* LSB...MSB   */
        c_st.site = &b_emlrtRSI;
        Matrix_Mul_With_Errors(&c_st, Mat_Size, C, Cerr);
        c_st.site = &c_emlrtRSI;
        ABFTError(&c_st, Cerr, &overflow, unusedU0);
        i1 = arr_ABFT->size[0];
        i2 = (int32_T)(1U + i);
        if ((i2 < 1) || (i2 > i1)) {
          emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &emlrtBCI, &b_st);
        }

        arr_ABFT->data[i2 - 1] = overflow;
        i1 = C->size[0] * C->size[1];
        loop_ub = Cerr->size[0] * Cerr->size[1];
        if (i1 != loop_ub) {
          emlrtSizeEqCheck1DR2012b(i1, loop_ub, &emlrtECI, &b_st);
        }

        c_st.site = &d_emlrtRSI;
        i1 = x->size[0];
        x->size[0] = C->size[0] * C->size[1];
        emxEnsureCapacity_real_T(&c_st, x, i1, &d_emlrtRTEI);
        loop_ub = C->size[0] * C->size[1];
        for (i1 = 0; i1 < loop_ub; i1++) {
          x->data[i1] = C->data[i1] - Cerr->data[i1];
        }

        d_st.site = &dc_emlrtRSI;
        nx = x->size[0];
        x_idx_0 = (uint32_T)x->size[0];
        i1 = r0->size[0];
        r0->size[0] = (int32_T)x_idx_0;
        emxEnsureCapacity_real_T(&d_st, r0, i1, &e_emlrtRTEI);
        e_st.site = &ec_emlrtRSI;
        overflow = ((1 <= x->size[0]) && (x->size[0] > 2147483646));
        if (overflow) {
          f_st.site = &lb_emlrtRSI;
          check_forloop_overflow_error(&f_st);
        }

        for (loop_ub = 0; loop_ub < nx; loop_ub++) {
          r0->data[loop_ub] = muDoubleScalarAbs(x->data[loop_ub]);
        }

        i1 = arr_Real->size[0];
        if ((i2 < 1) || (i2 > i1)) {
          emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &b_emlrtBCI, &b_st);
        }

        c_st.site = &d_emlrtRSI;
        arr_Real->data[i2 - 1] = (b_sum(&c_st, r0) > 0.0);

        /*      if arr_ABFT(i) ~= arr_Real(i) */
        /*          counter = counter + 1; */
        /*      end */
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(&b_st);
        }
      } else {
        emlrtHadParallelError = true;
      }
    }

    if (!emlrtHadParallelError) {
      emlrtHeapReferenceStackLeaveScope(&b_st, 5);
      emxFree_boolean_T(&unusedU0);
      emxFree_real_T(&Cerr);
      emxFree_real_T(&C);
      emxFree_real_T(&x);
      emxFree_real_T(&r0);
    }
  }

  if (!omp_in_parallel()) {
    c_st.site = &i_emlrtRSI;
    c_eml_rand_mt19937ar_stateful_s(false);
    c_st.site = &i_emlrtRSI;
    eml_rand_swap();
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
  emlrtAssertMATLABThread(sp, &b_emlrtRTEI);
  emlrtAssertMATLABThread(sp, &b_emlrtRTEI);
  st.site = &e_emlrtRSI;
  u_tv_sec = toc(&st);
  y = NULL;
  m2 = emlrtCreateDoubleScalar(u_tv_sec);
  emlrtAssign(&y, m2);
  emlrtDisplayR2012b(y, "ans", &b_emlrtRTEI, sp);
  y = NULL;
  m3 = emlrtCreateCharArray(2, iv0);
  emlrtInitCharArrayR2013a(sp, 37, m3, &u[0]);
  emlrtAssign(&y, m3);
  st.site = &mc_emlrtRSI;
  disp(&st, y, &emlrtMCI);
  st.site = &f_emlrtRSI;
  u_tv_sec = b_sum(&st, arr_ABFT);
  y = NULL;
  m4 = emlrtCreateDoubleScalar(u_tv_sec);
  emlrtAssign(&y, m4);
  st.site = &f_emlrtRSI;
  disp(&st, y, &b_emlrtMCI);
  y = NULL;
  m5 = emlrtCreateCharArray(2, iv1);
  emlrtInitCharArrayR2013a(sp, 33, m5, &b_u[0]);
  emlrtAssign(&y, m5);
  st.site = &lc_emlrtRSI;
  disp(&st, y, &c_emlrtMCI);
  st.site = &g_emlrtRSI;
  u_tv_sec = b_sum(&st, arr_Real);
  y = NULL;
  m6 = emlrtCreateDoubleScalar(u_tv_sec);
  emlrtAssign(&y, m6);
  st.site = &g_emlrtRSI;
  disp(&st, y, &d_emlrtMCI);
  y = NULL;
  m7 = emlrtCreateCharArray(2, iv2);
  emlrtInitCharArrayR2013a(sp, 30, m7, &c_u[0]);
  emlrtAssign(&y, m7);
  st.site = &kc_emlrtRSI;
  disp(&st, y, &e_emlrtMCI);
  st.site = &h_emlrtRSI;
  u_tv_sec = b_sum(&st, arr_Real) - b_sum(&st, arr_ABFT);
  y = NULL;
  m8 = emlrtCreateDoubleScalar(u_tv_sec);
  emlrtAssign(&y, m8);
  st.site = &h_emlrtRSI;
  disp(&st, y, &f_emlrtMCI);
  emxFree_real_T(&arr_Real);
  emxFree_real_T(&arr_ABFT);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (matMulerrApp.c) */
