/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rand.c
 *
 * Code generation for function 'rand'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "rand.h"
#include "eml_rand.h"
#include "matMulerrApp_emxutil.h"

/* Variable Definitions */
static emlrtRSInfo v_emlrtRSI = { 14,  /* lineNo */
  "rand",                              /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/rand.m"/* pathName */
};

static emlrtRSInfo w_emlrtRSI = { 114, /* lineNo */
  "rand",                              /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/rand.m"/* pathName */
};

static emlrtRTEInfo s_emlrtRTEI = { 1, /* lineNo */
  14,                                  /* colNo */
  "rand",                              /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/rand.m"/* pName */
};

static emlrtDCInfo j_emlrtDCI = { 100, /* lineNo */
  34,                                  /* colNo */
  "rand",                              /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/rand.m",/* pName */
  4                                    /* checkKind */
};

/* Function Definitions */
void b_rand(const emlrtStack *sp, real_T varargin_1, real_T varargin_2,
            emxArray_real_T *r)
{
  boolean_T EXTRINSIC;
  int32_T i8;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &v_emlrtRSI;
  if (!emlrtIsInParallelRegion(&st)) {
    EXTRINSIC = true;
  } else {
    EXTRINSIC = false;
  }

  if (EXTRINSIC) {
    i8 = r->size[0] * r->size[1];
    if (!(varargin_1 >= 0.0)) {
      emlrtNonNegativeCheckR2012b(varargin_1, &j_emlrtDCI, sp);
    }

    r->size[0] = (int32_T)varargin_1;
    if (!(varargin_2 >= 0.0)) {
      emlrtNonNegativeCheckR2012b(varargin_2, &j_emlrtDCI, sp);
    }

    r->size[1] = (int32_T)varargin_2;
    emxEnsureCapacity_real_T(sp, r, i8, &s_emlrtRTEI);
    if ((r->size[0] != 0) && (r->size[1] != 0)) {
      emlrtRandu(&r->data[0], r->size[0] * r->size[1]);
    }
  } else {
    st.site = &w_emlrtRSI;
    eml_rand(&st, varargin_1, varargin_2, r);
  }
}

real_T c_rand(const emlrtStack *sp)
{
  real_T r;
  boolean_T EXTRINSIC;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &v_emlrtRSI;
  if (!emlrtIsInParallelRegion(&st)) {
    EXTRINSIC = true;
  } else {
    EXTRINSIC = false;
  }

  if (EXTRINSIC) {
    emlrtRandu(&r, 1);
  } else {
    st.site = &w_emlrtRSI;
    r = b_eml_rand(&st);
  }

  return r;
}

/* End of code generation (rand.c) */
