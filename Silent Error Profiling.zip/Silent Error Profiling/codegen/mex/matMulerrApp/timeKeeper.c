/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * timeKeeper.c
 *
 * Code generation for function 'timeKeeper'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "timeKeeper.h"
#include "matMulerrApp_data.h"

/* Type Definitions */
#ifndef typedef_struct_T
#define typedef_struct_T

typedef struct {
  real_T tv_sec;
  real_T tv_nsec;
} struct_T;

#endif                                 /*typedef_struct_T*/

/* Variable Definitions */
static struct_T savedTime;
static boolean_T savedTime_not_empty;
static emlrtRSInfo n_emlrtRSI = { 14,  /* lineNo */
  "timeKeeper",                        /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/private/timeKeeper.m"/* pathName */
};

static emlrtRTEInfo ac_emlrtRTEI = { 12,/* lineNo */
  9,                                   /* colNo */
  "timeKeeper",                        /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/private/timeKeeper.m"/* pName */
};

/* Function Definitions */
void b_timeKeeper(const emlrtStack *sp, real_T *outTime_tv_sec, real_T
                  *outTime_tv_nsec)
{
  if (!savedTime_not_empty) {
    emlrtErrorWithMessageIdR2018a(sp, &ac_emlrtRTEI,
      "MATLAB:toc:callTicFirstNoInputs", "MATLAB:toc:callTicFirstNoInputs", 0);
  }

  *outTime_tv_sec = savedTime.tv_sec;
  *outTime_tv_nsec = savedTime.tv_nsec;
}

void timeKeeper(const emlrtStack *sp, real_T newTime_tv_sec, real_T
                newTime_tv_nsec)
{
  int32_T status;
  emlrtTimespec b_timespec;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  if (!savedTime_not_empty) {
    st.site = &n_emlrtRSI;
    b_st.site = &l_emlrtRSI;
    status = emlrtClockGettimeMonotonic(&b_timespec);
    c_st.site = &m_emlrtRSI;
    if (status != 0) {
      emlrtErrorWithMessageIdR2018a(&c_st, &lb_emlrtRTEI,
        "Coder:toolbox:POSIXCallFailed", "Coder:toolbox:POSIXCallFailed", 5, 4,
        26, cv0, 12, status);
    }

    savedTime.tv_sec = b_timespec.tv_sec;
    savedTime.tv_nsec = b_timespec.tv_nsec;
    savedTime_not_empty = true;
  }

  savedTime.tv_sec = newTime_tv_sec;
  savedTime.tv_nsec = newTime_tv_nsec;
}

void timeKeeper_free(void)
{
  savedTime_not_empty = false;
}

/* End of code generation (timeKeeper.c) */
