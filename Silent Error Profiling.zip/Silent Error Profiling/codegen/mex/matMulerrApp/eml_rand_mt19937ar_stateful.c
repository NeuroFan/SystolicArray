/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_rand_mt19937ar_stateful.c
 *
 * Code generation for function 'eml_rand_mt19937ar_stateful'
 *
 */

/* Include files */
#include <string.h>
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "matMulerrApp_emxutil.h"

/* Variable Definitions */
static uint32_T c_state[625];

#pragma omp threadprivate (c_state)

static boolean_T c_state_not_empty = false;

#pragma omp threadprivate (c_state_not_empty)

static uint32_T state_master[625];
static uint32_T (*state_ptr)[625];

#pragma omp threadprivate (state_ptr)

static boolean_T state_not_empty_master = false;
static emlrtRSInfo y_emlrtRSI = { 15,  /* lineNo */
  "eml_rand_mt19937ar_stateful",       /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/private/eml_rand_mt19937ar_stateful.m"/* pathName */
};

static emlrtRSInfo ab_emlrtRSI = { 51, /* lineNo */
  "eml_rand_mt19937ar",                /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/eml_rand_mt19937ar.m"/* pathName */
};

static emlrtRSInfo jc_emlrtRSI = { 9,  /* lineNo */
  "eml_rand_mt19937ar_stateful",       /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/private/eml_rand_mt19937ar_stateful.m"/* pathName */
};

static emlrtRTEInfo t_emlrtRTEI = { 1, /* lineNo */
  14,                                  /* colNo */
  "eml_rand_mt19937ar_stateful",       /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/private/eml_rand_mt19937ar_stateful.m"/* pName */
};

static emlrtDCInfo k_emlrtDCI = { 13,  /* lineNo */
  30,                                  /* colNo */
  "eml_rand_mt19937ar_stateful",       /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/private/eml_rand_mt19937ar_stateful.m",/* pName */
  4                                    /* checkKind */
};

static emlrtRTEInfo bc_emlrtRTEI = { 158,/* lineNo */
  17,                                  /* colNo */
  "genrandu",                          /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/eml_rand_mt19937ar.m"/* pName */
};

/* Function Declarations */
static real_T b_eml_rand_mt19937ar(const emlrtStack *sp, uint32_T d_state[625]);
static void eml_rand_mt19937ar(const emlrtStack *sp, uint32_T d_state[625]);

/* Function Definitions */
static real_T b_eml_rand_mt19937ar(const emlrtStack *sp, uint32_T d_state[625])
{
  real_T r;
  int32_T exitg1;
  int32_T k;
  uint32_T u[2];
  uint32_T mti;
  int32_T kk;
  uint32_T y;
  boolean_T isvalid;
  boolean_T exitg2;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &ab_emlrtRSI;

  /* ========================= COPYRIGHT NOTICE ============================ */
  /*  This is a uniform (0,1) pseudorandom number generator based on:        */
  /*                                                                         */
  /*  A C-program for MT19937, with initialization improved 2002/1/26.       */
  /*  Coded by Takuji Nishimura and Makoto Matsumoto.                        */
  /*                                                                         */
  /*  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,      */
  /*  All rights reserved.                                                   */
  /*                                                                         */
  /*  Redistribution and use in source and binary forms, with or without     */
  /*  modification, are permitted provided that the following conditions     */
  /*  are met:                                                               */
  /*                                                                         */
  /*    1. Redistributions of source code must retain the above copyright    */
  /*       notice, this list of conditions and the following disclaimer.     */
  /*                                                                         */
  /*    2. Redistributions in binary form must reproduce the above copyright */
  /*       notice, this list of conditions and the following disclaimer      */
  /*       in the documentation and/or other materials provided with the     */
  /*       distribution.                                                     */
  /*                                                                         */
  /*    3. The names of its contributors may not be used to endorse or       */
  /*       promote products derived from this software without specific      */
  /*       prior written permission.                                         */
  /*                                                                         */
  /*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    */
  /*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      */
  /*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  */
  /*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT  */
  /*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  */
  /*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       */
  /*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  */
  /*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  */
  /*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    */
  /*  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE */
  /*  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  */
  /*                                                                         */
  /* =============================   END   ================================= */
  do {
    exitg1 = 0;
    for (k = 0; k < 2; k++) {
      mti = d_state[624] + 1U;
      if (mti >= 625U) {
        for (kk = 0; kk < 227; kk++) {
          y = (d_state[kk] & 2147483648U) | (d_state[1 + kk] & 2147483647U);
          if ((y & 1U) == 0U) {
            y >>= 1U;
          } else {
            y = y >> 1U ^ 2567483615U;
          }

          d_state[kk] = d_state[kk + 397] ^ y;
        }

        for (kk = 0; kk < 396; kk++) {
          y = (d_state[kk + 227] & 2147483648U) | (d_state[228 + kk] &
            2147483647U);
          if ((y & 1U) == 0U) {
            y >>= 1U;
          } else {
            y = y >> 1U ^ 2567483615U;
          }

          d_state[kk + 227] = d_state[kk] ^ y;
        }

        y = (d_state[623] & 2147483648U) | (d_state[0] & 2147483647U);
        if ((y & 1U) == 0U) {
          y >>= 1U;
        } else {
          y = y >> 1U ^ 2567483615U;
        }

        d_state[623] = d_state[396] ^ y;
        mti = 1U;
      }

      y = d_state[(int32_T)mti - 1];
      d_state[624] = mti;
      y ^= y >> 11U;
      y ^= y << 7U & 2636928640U;
      y ^= y << 15U & 4022730752U;
      u[k] = y ^ y >> 18U;
    }

    u[0] >>= 5U;
    u[1] >>= 6U;
    r = 1.1102230246251565E-16 * ((real_T)u[0] * 6.7108864E+7 + (real_T)u[1]);
    if (r == 0.0) {
      if ((d_state[624] >= 1U) && (d_state[624] < 625U)) {
        isvalid = true;
      } else {
        isvalid = false;
      }

      if (isvalid) {
        isvalid = false;
        k = 1;
        exitg2 = false;
        while ((!exitg2) && (k < 625)) {
          if (d_state[k - 1] == 0U) {
            k++;
          } else {
            isvalid = true;
            exitg2 = true;
          }
        }
      }

      if (!isvalid) {
        emlrtErrorWithMessageIdR2018a(&st, &bc_emlrtRTEI,
          "Coder:MATLAB:rand_invalidTwisterState",
          "Coder:MATLAB:rand_invalidTwisterState", 0);
      }
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return r;
}

static void eml_rand_mt19937ar(const emlrtStack *sp, uint32_T d_state[625])
{
  uint32_T r;
  int32_T mti;
  if (emlrtIsInParallelRegion(sp)) {
    mti = getThreadID();
    if (mti > 2147483646) {
      mti = MAX_int32_T;
    } else {
      mti++;
    }

    if (mti < 0) {
      mti = 0;
    }

    r = (uint32_T)mti;
    d_state[0] = (uint32_T)mti;
    for (mti = 0; mti < 623; mti++) {
      r = ((r ^ r >> 30U) * 1812433253U + mti) + 1U;
      d_state[mti + 1] = r;
    }

    d_state[624] = 624U;
  } else {
    r = 5489U;
    d_state[0] = 5489U;
    for (mti = 0; mti < 623; mti++) {
      r = ((r ^ r >> 30U) * 1812433253U + mti) + 1U;
      d_state[mti + 1] = r;
    }

    d_state[624] = 624U;
  }
}

real_T b_eml_rand_mt19937ar_stateful(const emlrtStack *sp)
{
  real_T r;
  uint32_T d_state[625];
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  memcpy(&d_state[0], &(*state_ptr)[0], 625U * sizeof(uint32_T));
  st.site = &y_emlrtRSI;
  r = b_eml_rand_mt19937ar(&st, d_state);
  memcpy(&(*state_ptr)[0], &d_state[0], 625U * sizeof(uint32_T));
  return r;
}

void c_eml_rand_mt19937ar_stateful_f(const emlrtStack *sp)
{
  int32_T ub_loop;
  int32_T i;
  jmp_buf * volatile emlrtJBStack;
  ub_loop = omp_get_max_threads();
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);

#pragma omp parallel for schedule(static)\
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs()))

  for (i = 1; i <= ub_loop; i++) {
    c_state_not_empty = false;
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
  state_not_empty_master = false;
}

void c_eml_rand_mt19937ar_stateful_i(const emlrtStack *sp)
{
  int32_T ub_loop;
  int32_T i;
  uint32_T uv0[625];
  uint32_T uv1[625];
  jmp_buf * volatile emlrtJBStack;
  emlrtStack st;
  jmp_buf b_emlrtJBEnviron;
  emlrtStack b_st;
  emlrtStack c_st;
  boolean_T emlrtHadParallelError = false;
  b_st.prev = sp;
  b_st.tls = sp->tls;
  ub_loop = omp_get_max_threads();
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);

#pragma omp parallel \
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs())) \
 private(b_emlrtJBEnviron,c_st,uv1) \
 firstprivate(st,emlrtHadParallelError)

  {
    if (setjmp(b_emlrtJBEnviron) == 0) {
      st.prev = sp;
      st.tls = emlrtAllocTLS(sp, omp_get_thread_num());
      st.site = NULL;
      emlrtSetJmpBuf(&st, &b_emlrtJBEnviron);
      c_st.prev = &st;
      c_st.tls = st.tls;
    } else {
      emlrtHadParallelError = true;
    }

#pragma omp for schedule(static)

    for (i = 1; i <= ub_loop; i++) {
      if (emlrtHadParallelError)
        continue;
      if (setjmp(b_emlrtJBEnviron) == 0) {
        state_ptr = (uint32_T (*)[625])c_state;
        c_st.site = &jc_emlrtRSI;
        eml_rand_mt19937ar(&c_st, uv1);
        memcpy(&c_state[0], &uv1[0], 625U * sizeof(uint32_T));
        c_state_not_empty = true;
      } else {
        emlrtHadParallelError = true;
      }
    }
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
  memcpy(&state_master[0], &c_state[0], 625U * sizeof(uint32_T));
  b_st.site = &jc_emlrtRSI;
  eml_rand_mt19937ar(&b_st, uv0);
  memcpy(&c_state[0], &uv0[0], 625U * sizeof(uint32_T));
  c_state_not_empty = true;
}

void c_eml_rand_mt19937ar_stateful_s(boolean_T aToMaster)
{
  boolean_T state_not_empty_tmp;
  if (aToMaster) {
    state_ptr = (uint32_T (*)[625])state_master;
  } else {
    state_ptr = (uint32_T (*)[625])c_state;
  }

  state_not_empty_tmp = c_state_not_empty;
  c_state_not_empty = state_not_empty_master;
  state_not_empty_master = state_not_empty_tmp;
}

void eml_rand_mt19937ar_stateful(const emlrtStack *sp, real_T varargin_1, real_T
  varargin_2, emxArray_real_T *r)
{
  int32_T i9;
  int32_T k;
  uint32_T d_state[625];
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  i9 = r->size[0] * r->size[1];
  if (!(varargin_1 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(varargin_1, &k_emlrtDCI, sp);
  }

  r->size[0] = (int32_T)varargin_1;
  if (!(varargin_2 >= 0.0)) {
    emlrtNonNegativeCheckR2012b(varargin_2, &k_emlrtDCI, sp);
  }

  r->size[1] = (int32_T)varargin_2;
  emxEnsureCapacity_real_T(sp, r, i9, &t_emlrtRTEI);
  i9 = r->size[0] * r->size[1];
  for (k = 0; k < i9; k++) {
    memcpy(&d_state[0], &(*state_ptr)[0], 625U * sizeof(uint32_T));
    st.site = &y_emlrtRSI;
    r->data[k] = b_eml_rand_mt19937ar(&st, d_state);
    memcpy(&(*state_ptr)[0], &d_state[0], 625U * sizeof(uint32_T));
  }
}

/* End of code generation (eml_rand_mt19937ar_stateful.c) */
