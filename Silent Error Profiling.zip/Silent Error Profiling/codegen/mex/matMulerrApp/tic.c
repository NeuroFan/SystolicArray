/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * tic.c
 *
 * Code generation for function 'tic'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "tic.h"
#include "timeKeeper.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static emlrtRSInfo j_emlrtRSI = { 31,  /* lineNo */
  "tic",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/tic.m"/* pathName */
};

static emlrtRSInfo k_emlrtRSI = { 37,  /* lineNo */
  "tic",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/tic.m"/* pathName */
};

/* Function Definitions */
void tic(const emlrtStack *sp, real_T *tstart_tv_sec, real_T *tstart_tv_nsec)
{
  int32_T status;
  emlrtTimespec b_timespec;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &j_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  b_st.site = &l_emlrtRSI;
  status = emlrtClockGettimeMonotonic(&b_timespec);
  c_st.site = &m_emlrtRSI;
  if (status != 0) {
    emlrtErrorWithMessageIdR2018a(&c_st, &lb_emlrtRTEI,
      "Coder:toolbox:POSIXCallFailed", "Coder:toolbox:POSIXCallFailed", 5, 4, 26,
      cv0, 12, status);
  }

  *tstart_tv_sec = b_timespec.tv_sec;
  *tstart_tv_nsec = b_timespec.tv_nsec;
  st.site = &k_emlrtRSI;
  b_st.site = &l_emlrtRSI;
  status = emlrtClockGettimeMonotonic(&b_timespec);
  c_st.site = &m_emlrtRSI;
  if (status != 0) {
    emlrtErrorWithMessageIdR2018a(&c_st, &lb_emlrtRTEI,
      "Coder:toolbox:POSIXCallFailed", "Coder:toolbox:POSIXCallFailed", 5, 4, 26,
      cv0, 12, status);
  }

  st.site = &k_emlrtRSI;
  timeKeeper(&st, b_timespec.tv_sec, b_timespec.tv_nsec);
}

/* End of code generation (tic.c) */
