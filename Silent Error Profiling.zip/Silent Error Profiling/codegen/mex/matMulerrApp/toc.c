/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * toc.c
 *
 * Code generation for function 'toc'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "toc.h"
#include "timeKeeper.h"
#include "matMulerrApp_mexutil.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static emlrtRSInfo fc_emlrtRSI = { 31, /* lineNo */
  "toc",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/toc.m"/* pathName */
};

static emlrtRSInfo gc_emlrtRSI = { 36, /* lineNo */
  "toc",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/toc.m"/* pathName */
};

static emlrtRSInfo hc_emlrtRSI = { 44, /* lineNo */
  "toc",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/toc.m"/* pathName */
};

static emlrtRSInfo ic_emlrtRSI = { 38, /* lineNo */
  "fprintf",                           /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pathName */
};

static emlrtMCInfo g_emlrtMCI = { 60,  /* lineNo */
  18,                                  /* colNo */
  "fprintf",                           /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pName */
};

static emlrtRSInfo nc_emlrtRSI = { 60, /* lineNo */
  "fprintf",                           /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pathName */
};

/* Function Declarations */
static const mxArray *feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, emlrtMCInfo *location);

/* Function Definitions */
static const mxArray *feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, emlrtMCInfo *location)
{
  const mxArray *pArrays[4];
  const mxArray *m13;
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  pArrays[3] = e;
  return emlrtCallMATLABR2012b(sp, 1, &m13, 4, pArrays, "feval", true, location);
}

real_T toc(const emlrtStack *sp)
{
  real_T t;
  real_T tstart_tv_sec;
  real_T tstart_tv_nsec;
  int32_T status;
  emlrtTimespec b_timespec;
  const mxArray *y;
  const mxArray *m9;
  static const int32_T iv4[2] = { 1, 7 };

  static const char_T u[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  const mxArray *b_y;
  const mxArray *m10;
  const mxArray *c_y;
  const mxArray *m11;
  static const int32_T iv5[2] = { 1, 28 };

  static const char_T b_u[28] = { 'E', 'l', 'a', 'p', 's', 'e', 'd', ' ', 't',
    'i', 'm', 'e', ' ', 'i', 's', ' ', '%', 'f', ' ', 's', 'e', 'c', 'o', 'n',
    'd', 's', '\\', 'n' };

  const mxArray *d_y;
  const mxArray *m12;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &fc_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  b_timeKeeper(&st, &tstart_tv_sec, &tstart_tv_nsec);
  st.site = &gc_emlrtRSI;
  b_st.site = &l_emlrtRSI;
  status = emlrtClockGettimeMonotonic(&b_timespec);
  c_st.site = &m_emlrtRSI;
  if (status != 0) {
    emlrtErrorWithMessageIdR2018a(&c_st, &lb_emlrtRTEI,
      "Coder:toolbox:POSIXCallFailed", "Coder:toolbox:POSIXCallFailed", 5, 4, 26,
      cv0, 12, status);
  }

  t = (b_timespec.tv_sec - tstart_tv_sec) + (b_timespec.tv_nsec - tstart_tv_nsec)
    / 1.0E+9;
  st.site = &hc_emlrtRSI;
  b_st.site = &ic_emlrtRSI;
  y = NULL;
  m9 = emlrtCreateCharArray(2, iv4);
  emlrtInitCharArrayR2013a(&b_st, 7, m9, &u[0]);
  emlrtAssign(&y, m9);
  b_y = NULL;
  m10 = emlrtCreateDoubleScalar(1.0);
  emlrtAssign(&b_y, m10);
  c_y = NULL;
  m11 = emlrtCreateCharArray(2, iv5);
  emlrtInitCharArrayR2013a(&b_st, 28, m11, &b_u[0]);
  emlrtAssign(&c_y, m11);
  d_y = NULL;
  m12 = emlrtCreateDoubleScalar(t);
  emlrtAssign(&d_y, m12);
  c_st.site = &nc_emlrtRSI;
  emlrt_marshallIn(&c_st, feval(&c_st, y, b_y, c_y, d_y, &g_emlrtMCI),
                   "<output of feval>");
  return t;
}

/* End of code generation (toc.c) */
