/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mat_ext.h
 *
 * Code generation for function 'mat_ext'
 *
 */

#ifndef MAT_EXT_H
#define MAT_EXT_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void mat_ext(const emlrtStack *sp, const emxArray_real_T *A,
                    emxArray_real_T *A_col_ext, emxArray_real_T *A_row_ext,
                    emxArray_real_T *A_both_ext);

#endif

/* End of code generation (mat_ext.h) */
