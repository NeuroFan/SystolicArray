/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_matMulerrApp_mex.c
 *
 * Code generation for function '_coder_matMulerrApp_mex'
 *
 */

/* Include files */
#include "matMulerrApp.h"
#include "_coder_matMulerrApp_mex.h"
#include "matMulerrApp_terminate.h"
#include "_coder_matMulerrApp_api.h"
#include "matMulerrApp_initialize.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
static jmp_buf emlrtJBEnviron;

/* Function Declarations */
static void matMulerrApp_mexFunction(int32_T nlhs, int32_T nrhs, const mxArray
  *prhs[2]);

/* Function Definitions */
static void matMulerrApp_mexFunction(int32_T nlhs, int32_T nrhs, const mxArray
  *prhs[2])
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;

  /* Check for proper number of arguments. */
  if (nrhs != 2) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 2, 4,
                        12, "matMulerrApp");
  }

  if (nlhs > 0) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 12,
                        "matMulerrApp");
  }

  /* Call the function. */
  matMulerrApp_api(prhs, nlhs);
}

void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const mxArray
                 *prhs[])
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  (void)plhs;
  mexAtExit(matMulerrApp_atexit);
  emlrtLoadMATLABLibrary("sys/os/glnxa64/libiomp5.so");

  /* Initialize the memory manager. */
  omp_init_lock(&emlrtLockGlobal);
  omp_init_nest_lock(&emlrtNestLockGlobal);

  /* Module initialization. */
  matMulerrApp_initialize();
  st.tls = emlrtRootTLSGlobal;
  emlrtSetJmpBuf(&st, &emlrtJBEnviron);
  if (setjmp(emlrtJBEnviron) == 0) {
    /* Dispatch the entry-point. */
    matMulerrApp_mexFunction(nlhs, nrhs, prhs);

    /* Module termination. */
    matMulerrApp_terminate();
    omp_destroy_lock(&emlrtLockGlobal);
    omp_destroy_nest_lock(&emlrtNestLockGlobal);
  } else {
    omp_destroy_lock(&emlrtLockGlobal);
    omp_destroy_nest_lock(&emlrtNestLockGlobal);
    emlrtReportParallelRunTimeError(&st);
  }
}

emlrtCTX mexFunctionCreateRootTLS(void)
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal,
                     emlrtLockerFunction, omp_get_num_procs());
  return emlrtRootTLSGlobal;
}

/* End of code generation (_coder_matMulerrApp_mex.c) */
