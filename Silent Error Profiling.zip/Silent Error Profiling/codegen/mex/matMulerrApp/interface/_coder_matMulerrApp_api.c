/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_matMulerrApp_api.c
 *
 * Code generation for function '_coder_matMulerrApp_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "_coder_matMulerrApp_api.h"
#include "toc.h"
#include "matMulerrApp_mexutil.h"
#include "matMulerrApp_data.h"

/* Function Definitions */
void matMulerrApp_api(const mxArray * const prhs[2], int32_T nlhs)
{
  real_T N;
  real_T Mat_Size;
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  (void)nlhs;
  st.tls = emlrtRootTLSGlobal;

  /* Marshall function inputs */
  N = emlrt_marshallIn(&st, emlrtAliasP(prhs[0]), "N");
  Mat_Size = emlrt_marshallIn(&st, emlrtAliasP(prhs[1]), "Mat_Size");

  /* Invoke the target function */
  matMulerrApp(&st, N, Mat_Size);
}

/* End of code generation (_coder_matMulerrApp_api.c) */
