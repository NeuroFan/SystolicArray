/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * randi.h
 *
 * Code generation for function 'randi'
 *
 */

#ifndef RANDI_H
#define RANDI_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "omp.h"
#include "matMulerrApp_types.h"

/* Function Declarations */
extern void randi(const emlrtStack *sp, real_T varargin_1, real_T varargin_2,
                  emxArray_real_T *r);

#endif

/* End of code generation (randi.h) */
