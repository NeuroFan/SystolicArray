/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_rand.c
 *
 * Code generation for function 'eml_rand'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "eml_rand.h"
#include "eml_rand_mt19937ar_stateful.h"

/* Variable Definitions */
static uint32_T method;

#pragma omp threadprivate (method)

static boolean_T method_not_empty = false;

#pragma omp threadprivate (method_not_empty)

static uint32_T method_master;
static boolean_T method_not_empty_master = false;
static emlrtRSInfo x_emlrtRSI = { 45,  /* lineNo */
  "eml_rand",                          /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/randfun/private/eml_rand.m"/* pathName */
};

/* Function Definitions */
real_T b_eml_rand(const emlrtStack *sp)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &x_emlrtRSI;
  return b_eml_rand_mt19937ar_stateful(&st);
}

void eml_rand(const emlrtStack *sp, real_T varargin_1, real_T varargin_2,
              emxArray_real_T *r)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &x_emlrtRSI;
  eml_rand_mt19937ar_stateful(&st, varargin_1, varargin_2, r);
}

void eml_rand_free(const emlrtStack *sp)
{
  int32_T ub_loop;
  int32_T i;
  jmp_buf * volatile emlrtJBStack;
  ub_loop = omp_get_max_threads();
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);

#pragma omp parallel for schedule(static)\
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs()))

  for (i = 1; i <= ub_loop; i++) {
    method_not_empty = false;
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
  method_not_empty_master = false;
}

void eml_rand_init(const emlrtStack *sp)
{
  int32_T ub_loop;
  int32_T i;
  jmp_buf * volatile emlrtJBStack;
  ub_loop = omp_get_max_threads();
  emlrtEnterParallelRegion(sp, omp_in_parallel());
  emlrtPushJmpBuf(sp, &emlrtJBStack);

#pragma omp parallel for schedule(static)\
 num_threads(emlrtAllocRegionTLSs(sp->tls, omp_in_parallel(), omp_get_max_threads(), omp_get_num_procs()))

  for (i = 1; i <= ub_loop; i++) {
    method = 7U;
  }

  emlrtPopJmpBuf(sp, &emlrtJBStack);
  emlrtExitParallelRegion(sp, omp_in_parallel());
  method_master = method;
  method = 7U;
  method_not_empty = true;
}

void eml_rand_swap(void)
{
  uint32_T method_tmp;
  boolean_T method_not_empty_tmp;
  method_tmp = method;
  method = method_master;
  method_master = method_tmp;
  method_not_empty_tmp = method_not_empty;
  method_not_empty = method_not_empty_master;
  method_not_empty_master = method_not_empty_tmp;
}

/* End of code generation (eml_rand.c) */
