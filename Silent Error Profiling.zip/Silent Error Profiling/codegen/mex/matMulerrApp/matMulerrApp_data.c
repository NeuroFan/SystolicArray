/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matMulerrApp_data.c
 *
 * Code generation for function 'matMulerrApp_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matMulerrApp.h"
#include "matMulerrApp_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
omp_lock_t emlrtLockGlobal;
omp_nest_lock_t emlrtNestLockGlobal;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131482U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "matMulerrApp",                      /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 1359525326U, 1794498124U, 1706448398U, 1131923105U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

emlrtRSInfo l_emlrtRSI = { 8,          /* lineNo */
  "getTime",                           /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/private/getTime.m"/* pathName */
};

emlrtRSInfo m_emlrtRSI = { 25,         /* lineNo */
  "getTimeEMLRT",                      /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/private/getTime.m"/* pathName */
};

emlrtRSInfo hb_emlrtRSI = { 9,         /* lineNo */
  "sum",                               /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/sum.m"/* pathName */
};

emlrtRSInfo ib_emlrtRSI = { 73,        /* lineNo */
  "sumprod",                           /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/sumprod.m"/* pathName */
};

emlrtRSInfo jb_emlrtRSI = { 134,       /* lineNo */
  "combineVectorElements",             /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/combineVectorElements.m"/* pathName */
};

emlrtRSInfo kb_emlrtRSI = { 193,       /* lineNo */
  "colMajorFlatIter",                  /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/combineVectorElements.m"/* pathName */
};

emlrtRSInfo lb_emlrtRSI = { 21,        /* lineNo */
  "eml_int_forloop_overflow_check",    /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"/* pathName */
};

emlrtRSInfo tb_emlrtRSI = { 121,       /* lineNo */
  "GET_N",                             /* fcnName */
  "/usr/local/matlab/toolbox/comm/comm/eml/de2bi.m"/* pathName */
};

emlrtRSInfo ub_emlrtRSI = { 125,       /* lineNo */
  "GET_N",                             /* fcnName */
  "/usr/local/matlab/toolbox/comm/comm/eml/de2bi.m"/* pathName */
};

emlrtRSInfo vb_emlrtRSI = { 45,        /* lineNo */
  "mpower",                            /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/ops/mpower.m"/* pathName */
};

emlrtRSInfo wb_emlrtRSI = { 55,        /* lineNo */
  "power",                             /* fcnName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/ops/power.m"/* pathName */
};

emlrtRTEInfo fb_emlrtRTEI = { 9,       /* lineNo */
  1,                                   /* colNo */
  "sum",                               /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/sum.m"/* pName */
};

emlrtRTEInfo gb_emlrtRTEI = { 134,     /* lineNo */
  13,                                  /* colNo */
  "combineVectorElements",             /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/datafun/private/combineVectorElements.m"/* pName */
};

emlrtRTEInfo lb_emlrtRTEI = { 83,      /* lineNo */
  9,                                   /* colNo */
  "checkPOSIXStatus",                  /* fName */
  "/usr/local/matlab/toolbox/eml/lib/matlab/timefun/private/getTime.m"/* pName */
};

const char_T cv0[26] = { 'e', 'm', 'l', 'r', 't', 'C', 'l', 'o', 'c', 'k', 'G',
  'e', 't', 't', 'i', 'm', 'e', 'M', 'o', 'n', 'o', 't', 'o', 'n', 'i', 'c' };

/* End of code generation (matMulerrApp_data.c) */
