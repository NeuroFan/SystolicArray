% extract error probability based on HSPICE data (HSPICE simulation results
% are a not smooth and make the reader misunderstand, the output is same

% V = 0.7, Fclk = 4ns

mu = 0;
sigma = .1; %ns
proabability = zeros(2,24);
i=0;
sigmas=0;
for sigma = 0.0:0.001:0.5  %ns
    i=i+1;
    sigmas(i)=sigma;
    pd = makedist('Normal','mu',mu,'sigma',sigma);
    proabalities(i,:)=cdf(pd,-0.1*[1.3,2.5:25]);
end
plot(sigmas,proabalities)

