    figure1 = figure
    
    subplot(2,1,1);
    plot(sigmas,proabalities);
    subplot(2,1,2);
    plot(sigmas,TE./N);         %% Total Error rate 
    hold on
    plot(sigmas,SE./N,'r')      %% silent error when we assume only 1 row has errornouse PE
    hold on
    plot(sigmas,(SE./N).^32,'g') %% Silent Error in realistic scenerion when all PEs more or less have same behavior (this results matches the measured results, the probablity is really really small)
    