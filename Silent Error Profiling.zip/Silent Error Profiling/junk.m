vdd = storeVdd_;
f_clk = store_f_clk_;
power = storeTotalPower_32x33_;
ABFT = 1.0.*storeABFT_Matrix_Fault_;

for i = 2:length(power)
        if storeVdd_(i)==storeVdd_(i-1)
            vdd(i)=-1;
            f_clk(i)=-1;
            power(i-1)=power(i-1)+power(i);
            ABFT(i)=-1;
        end
end
indx = vdd == -1;

vdd(indx)=[];
f_clk(indx)=[];
power(indx)=[];
ABFT(indx)=[];

subplot(2,1,1)
stairs(vdd,power);
subplot(2,1,2)
stairs(vdd,f_clk)