BitErr(24,100) = 0;
j= 0 ;
PrintFlag = 0;
%%
  XSP1 = loadsig(SPICE_output_Data);
  Range = 1:length(XSP1(1).data);
  resampledData = adjustData(XSP1,Range);
for variation_percent = (0:0.25:10)./2.78 % 2.78 in this case is necessary to make the std exactly variation_percent
  
    disp(variation_percent*2.78)
    j =j +1 ;
[ResultList1,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList2,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList3,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList4,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList5,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList6,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList7,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList8,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList9,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);
[ResultList10,~,~] = check_data_V2(resampledData,SPICE_output_Data,HSPICE_INPUT_DATA,SET_UP_TIME_percent,Vdd, variation_percent,PrintFlag);



Result.MulIn1 = [ResultList1.MulIn1, ResultList2.MulIn1 , ResultList3.MulIn1 , ResultList4.MulIn1 , ResultList5.MulIn1,...
                 ResultList6.MulIn1, ResultList7.MulIn1 , ResultList8.MulIn1 , ResultList9.MulIn1 , ResultList10.MulIn1];
Result.MulIn2 = [ResultList1.MulIn2, ResultList2.MulIn2, ResultList3.MulIn2 , ResultList4.MulIn2 , ResultList5.MulIn2,...
                 ResultList6.MulIn2, ResultList7.MulIn2, ResultList8.MulIn2 , ResultList9.MulIn2 , ResultList10.MulIn2 ];
Result.FeedAcc = [ResultList1.FeedAcc, ResultList2.FeedAcc, ResultList3.FeedAcc , ResultList4.FeedAcc , ResultList5.FeedAcc...
                  ResultList6.FeedAcc, ResultList7.FeedAcc, ResultList8.FeedAcc , ResultList9.FeedAcc , ResultList10.FeedAcc];
Result.Product = [ResultList1.Product, ResultList2.Product, ResultList3.Product , ResultList4.Product , ResultList5.Product,...
                  ResultList6.Product, ResultList7.Product, ResultList8.Product , ResultList9.Product , ResultList10.Product];
Result.GoldenProduct = [ResultList1.GoldenProduct, ResultList2.GoldenProduct, ResultList3.GoldenProduct , ResultList4.GoldenProduct , ResultList5.GoldenProduct,...
                        ResultList6.GoldenProduct, ResultList7.GoldenProduct, ResultList8.GoldenProduct , ResultList9.GoldenProduct , ResultList10.GoldenProduct];
Result.SumHSPICE = [ResultList1.SumHSPICE, ResultList2.SumHSPICE, ResultList3.SumHSPICE , ResultList4.SumHSPICE , ResultList5.SumHSPICE,...
                    ResultList6.SumHSPICE, ResultList7.SumHSPICE, ResultList8.SumHSPICE , ResultList9.SumHSPICE , ResultList10.SumHSPICE];
Result.GoldenSum = [ResultList1.GoldenSum, ResultList2.GoldenSum , ResultList3.GoldenSum , ResultList4.GoldenSum , ResultList5.GoldenSum,...
                    ResultList6.GoldenSum, ResultList7.GoldenSum , ResultList8.GoldenSum , ResultList9.GoldenSum , ResultList10.GoldenSum ];

%faultsList = clean_faultsList(faultsList); %removes all zero enteries


%
S = zeros(1,24);
P = zeros(1,16);
Xs = 0;
Len = length(Result.GoldenSum);
for i = 1:Len-1
    ActualSumBits = de2bi(Result.SumHSPICE(i),24);
    GoldenSumBits = de2bi(Result.GoldenSum(i),24);
    
    Xs = xor(ActualSumBits,GoldenSumBits);

    S = S + Xs;
end


% bar(2.*S./Len); %since half of entries are zero
% hold on

BitErr(:,j) = 2.*S./Len;

end