    tic
    clc
    clear
    close all
    N = 4000;
    BitLen = 24;
    mat_size =2;
    SE(1) = 0;
    ind = 0; 
    %for Coeff = 0:0.01:10
    run('probablity_simpler.m');
    figure
    
    for k = 1:length(sigmas)
        ind = ind+1 ;
        SilentErrCounter = 0;
        Total_error_counter = 0;

        %errDist = zeros(1,BitLen);
        %errDist = zeros(1,BitLen);%0.1*(1:BitLen)./BitLen;
        %errDist(end)=1;
        errDist = proabalities(k,:);
        %errDist(1:end-2)=0;
        %errDist(errDist>=1) = 1 ;% no error rate more that 1 
        
        parfor i = 1:N %possible race condition, check later
    %         [C,Cerr] =  Matrix_Mul_With_Errors(Mat_Size, err_rates);
    %         [arr_ABFT(i),~] = ABFTError(Cerr);
    %         arr_Real(i) = sum(abs(C(:)-Cerr(:)))>0;

            some_row_elements = randi([0 2^BitLen-1], mat_size,1);
            sumOriginal = 0;
            sumErr = 0;
            error_inject = 0;
            
            for j = 1:mat_size
                sumOriginal = sumOriginal + some_row_elements(j);

                e = inject_error(some_row_elements(j), errDist);
                sumErr = sumErr + e;

                error_inject = error_inject  + double(e~=some_row_elements(j))  ; % count number of times actually error was injected

            end

            if (error_inject~=0)  %count total errors
                Total_error_counter = Total_error_counter + 1;
            end
            
             if (sumErr== sumOriginal) && (error_inject~=0) % count silent errors
                 SilentErrCounter = SilentErrCounter + 1;
             end

        end
        TE(ind) = Total_error_counter;
        SE(ind) = SilentErrCounter;
        disp(['total error is ', num2str(Total_error_counter)]);
        disp(['silent error is ', num2str(sum(SE))]);
               
   end
    %plot(sigmas,100*SE./TE)
    
   run('generatefigure.m');

    