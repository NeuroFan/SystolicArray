function C = redo_matMul(faultsList,Mats)
    
    ArScale = Mats.ArScale;
    BcScale = Mats.BcScale;
    [N,~] = size(ArScale);
    C = zeros(N,N);
    for i = 1:N
        for j = 1:N
            for k = 1:N-1

                in1 = ArScale(i,k); % 1th input of mult
                in2 = BcScale(k,j); % 2th imput of mul
                feedAcc = C(i,j); % input to adder (feedbacked)
                if ( in1 + in2 +  feedAcc)==12+128+3392
                    ;%disp('here');
                end
                [Found, faultySum] = search_enties(in1,in2,feedAcc,faultsList);
                if (Found == 1)
                    Sum = faultySum;
                else
                    Sum = C(i,j) + in1*in2;
                end
                
                C(i,j) = Sum; % i.e. C(i,j) + p but using spice results;
            end
        end
    end

end

function [Found, faultySum] = search_enties(In1,In2,F,faultsList)
    faultySum = NaN;
    N = length(faultsList.MulIn1);
    Found = 0; %if return 0 means nothing found in list
    for i = 1:N
        
        In1_fromList = faultsList.MulIn1(i);
        In2_fromList = faultsList.MulIn2(i);
        feed_fromList = faultsList.FeedAcc(i); %feedback from accumulator
        Sum_fromList = faultsList.SumHSPICE(i);
        A_eq_B = (In1_fromList==In1) && (In2_fromList==In2) ;
        B_eq_A = (In1_fromList==In2) && (In2_fromList==In1) ;
        if (  ( A_eq_B  || B_eq_A) && (feed_fromList == F) )
            faultySum = Sum_fromList;
            Found = 1;
        else
            faultySum = NaN;
            Found = 0;
        end
        
    end
   

end